import { useState, useEffect } from "react";
import {
  BarChart, Bar, LineChart, Line, PieChart, Pie, Cell,
  XAxis, YAxis, CartesianGrid, Tooltip, Legend,
  ResponsiveContainer, AreaChart, Area, ComposedChart
} from "recharts";
import {
  getCAMensuel, getCACompar, getCACateg,
  getCAKpi, getCATrim, getCASaisonnier, getCAYtd
} from "../services/api";
import KpiCard from "../components/KpiCard";
import { useDashboard } from "../components/DashboardContext";
import { IconRevenue, IconMonitor, IconTrendUp, IconPercent, IconCalendar, IconCalendarOld, IconBarChart } from "../components/KpiIcons";
import ChartCard from "../components/ChartCard";
import Section from "../components/Section";

// ── Colors ───────────────────────────────────────────────────────────────────
const COLORS = ["#1E3A5F", "#2E86AB", "#A8DADC", "#457B9D"];
const SAISON_COLORS = { "Haute": "#1E3A5F", "Moyenne": "#2E86AB", "Basse": "#A8DADC" };

// ── Helpers ──────────────────────────────────────────────────────────────────
const fmtTND = (v) => `${(parseFloat(v||0)/1000).toFixed(1)} K TND`;
const fmtM   = (v) => `${(parseFloat(v||0)/1000000).toFixed(2)} M TND`;
const fmt    = (v, dec=0) => parseFloat(v||0).toLocaleString("fr-FR", { minimumFractionDigits:dec, maximumFractionDigits:dec });

const tooltipStyle = {
  background: "rgba(255,255,255,0.97)",
  borderRadius: 10,
  border: "1px solid rgba(26,143,209,0.3)",
  padding: "8px 10px",
  color: "#1a2b4a",
  boxShadow: "0 8px 24px rgba(26,103,180,0.15)",
};

const tooltipLabelStyle = {
  marginBottom: 4,
  fontSize: 11,
  fontWeight: 600,
  color: "#4a6080",
  textTransform: "uppercase",
  letterSpacing: "0.06em",
};

function Badge({ value }) {
  const v = parseFloat(value);
  return (
    <span className={`text-xs font-semibold px-2 py-0.5 rounded-full ${v >= 0 ? "bg-green-50 text-green-600" : "bg-red-50 text-red-500"}`}>
      {v > 0 ? "+" : ""}{v.toFixed(2)}%
    </span>
  );
}

export default function CA() {
  const { hotelId, annee } = useDashboard();
  const [mensuel, setMensuel] = useState([]);
  const [compar,  setCompar]  = useState([]);
  const [categ,   setCateg]   = useState([]);
  const [kpi,     setKpi]     = useState(null);
  const [trim,    setTrim]    = useState([]);
  const [saison,  setSaison]  = useState([]);
  const [ytd,     setYtd]     = useState(null);
  const [loading, setLoading] = useState(true);
  const [error,   setError]   = useState(null);

  useEffect(() => {
    setLoading(true);
    setError(null);
    Promise.all([
      getCAMensuel(annee, hotelId),
      getCACompar(annee, hotelId),
      getCACateg(annee, hotelId),
      getCAKpi(annee, hotelId),
      getCATrim(annee, hotelId),
      getCASaisonnier(annee, hotelId),
      getCAYtd(annee, hotelId),
    ])
      .then(([m, c, catRes, kpRes, trRes, saRes, ytRes]) => {
        setMensuel(m.data.data);
        setCompar(c.data.data);
        setCateg(catRes.data.data);
        setKpi(kpRes.data.data);
        setTrim(trRes.data.data);
        setSaison(saRes.data.data);
        setYtd(ytRes.data.data);
      })
      .catch((e) => {
        setError("Erreur de chargement des données : " + (e?.message || "backend inaccessible"));
      })
      .finally(() => setLoading(false));
  }, [annee, hotelId]);

  // Build cumul from mensuel if not stored
  const cumulData = mensuel.map((r, i) => ({
    ...r,
    ca_cumul_calc: mensuel.slice(0, i+1).reduce((s, x) => s + parseFloat(x.ca_ttc), 0),
  }));

  if (loading) return (
    <div className="flex items-center justify-center h-64">
      <div className="animate-spin rounded-full h-10 w-10 border-4 border-[#1E3A5F] border-t-transparent" />
    </div>
  );

  if (error) return (
    <div className="flex items-center justify-center h-64">
      <div className="text-center text-red-500">
        <p className="text-lg font-semibold mb-1">Erreur de chargement</p>
        <p className="text-sm text-gray-500">{error}</p>
      </div>
    </div>
  );

  return (
    <div className="p-6 max-w-screen-xl">

      <Section
        title="Vue d’ensemble du chiffre d’affaires"
        subtitle="Suivi synthétique du chiffre d’affaires annuel et year-to-date."
      />

      {/* 1. KPI GLOBAUX — redesigned */}
      {kpi && (() => {
        const n       = parseFloat(kpi.total_revenue_n||0);
        const n1      = parseFloat(kpi.total_revenue_n1||0);
        const growth  = parseFloat(kpi.total_growth_percentage||0);
        const isPos   = growth >= 0;
        const maxBar  = Math.max(n, n1);
        const growthColor = isPos ? "#1A6B3A" : "#C0392B";
        const growthBg    = isPos ? "rgba(26,107,58,0.06)" : "rgba(192,57,43,0.06)";
        return (
          <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr 1fr 1fr", gap:16, marginBottom:16 }}>

            {/* Card — CA N */}
            <div style={{ background:"rgba(255,255,255,0.88)", borderRadius:16, padding:"18px 20px", border:"1px solid rgba(180,210,235,0.8)", boxShadow:"0 2px 12px rgba(26,103,180,0.07)", position:"relative", overflow:"hidden" }}>
              <div style={{ position:"absolute", top:0, left:0, right:0, height:3, background:"linear-gradient(90deg,#1a8fd1,#1a8fd155)", borderRadius:"16px 16px 0 0" }}/>
              <div style={{ width:36, height:36, borderRadius:10, background:"rgba(26,143,209,0.1)", display:"flex", alignItems:"center", justifyContent:"center", color:"#1a8fd1", marginBottom:12 }}><IconRevenue /></div>
              <div style={{ fontSize:10, fontWeight:700, color:"#7a95b0", textTransform:"uppercase", letterSpacing:"0.1em", marginBottom:4 }}>CA Total {annee}</div>
              <div style={{ fontSize:26, fontWeight:800, color:"#1a2b4a", letterSpacing:"-0.04em", lineHeight:1 }}>{(n/1000000).toFixed(2)}<span style={{ fontSize:14, fontWeight:600, color:"#7a95b0", marginLeft:3 }}>M TND</span></div>
              <div style={{ marginTop:12 }}>
                <div style={{ display:"flex", justifyContent:"space-between", fontSize:9, color:"#7a95b0", marginBottom:3 }}>
                  <span>{annee}</span><span>100%</span>
                </div>
                <div style={{ height:6, borderRadius:99, background:"rgba(180,210,235,0.3)" }}>
                  <div style={{ height:"100%", width:"100%", background:"#1a8fd1", borderRadius:99 }}/>
                </div>
                <div style={{ display:"flex", justifyContent:"space-between", fontSize:9, color:"#7a95b0", marginTop:3 }}>
                  <span>{annee-1}</span><span>{n1 > 0 ? ((n1/n)*100).toFixed(0) : 0}%</span>
                </div>
                <div style={{ height:6, borderRadius:99, background:"rgba(180,210,235,0.3)" }}>
                  <div style={{ height:"100%", width:`${maxBar>0?(n1/maxBar*100):0}%`, background:"#A8DADC", borderRadius:99 }}/>
                </div>
              </div>
            </div>

            {/* Card — CA N-1 */}
            <div style={{ background:"rgba(255,255,255,0.88)", borderRadius:16, padding:"18px 20px", border:"1px solid rgba(180,210,235,0.8)", boxShadow:"0 2px 12px rgba(26,103,180,0.07)", position:"relative", overflow:"hidden" }}>
              <div style={{ position:"absolute", top:0, left:0, right:0, height:3, background:"linear-gradient(90deg,#0e9fce,#0e9fce55)", borderRadius:"16px 16px 0 0" }}/>
              <div style={{ width:36, height:36, borderRadius:10, background:"rgba(14,159,206,0.1)", display:"flex", alignItems:"center", justifyContent:"center", color:"#0e9fce", marginBottom:12 }}><IconMonitor /></div>
              <div style={{ fontSize:10, fontWeight:700, color:"#7a95b0", textTransform:"uppercase", letterSpacing:"0.1em", marginBottom:4 }}>CA Total {annee-1}</div>
              <div style={{ fontSize:26, fontWeight:800, color:"#1a2b4a", letterSpacing:"-0.04em", lineHeight:1 }}>{(n1/1000000).toFixed(2)}<span style={{ fontSize:14, fontWeight:600, color:"#7a95b0", marginLeft:3 }}>M TND</span></div>
              <div style={{ marginTop:12, fontSize:10, color:"#7a95b0" }}>
                <div style={{ display:"flex", alignItems:"center", gap:6, marginTop:6 }}>
                  <span style={{ fontSize:11, fontWeight:600 }}>Écart vs {annee} :</span>
                  <span style={{ fontWeight:800, color:growthColor, fontSize:13 }}>{isPos ? "+" : ""}{((n-n1)/1000000).toFixed(2)} M TND</span>
                </div>
              </div>
            </div>

            {/* Card — Croissance TND */}
            <div style={{ background:"rgba(255,255,255,0.88)", borderRadius:16, padding:"18px 20px", border:"1px solid rgba(180,210,235,0.8)", boxShadow:"0 2px 12px rgba(26,103,180,0.07)", position:"relative", overflow:"hidden" }}>
              <div style={{ position:"absolute", top:0, left:0, right:0, height:3, background:"linear-gradient(90deg,#c9a84c,#c9a84c55)", borderRadius:"16px 16px 0 0" }}/>
              <div style={{ width:36, height:36, borderRadius:10, background:"rgba(201,168,76,0.1)", display:"flex", alignItems:"center", justifyContent:"center", color:"#c9a84c", marginBottom:12 }}><IconTrendUp /></div>
              <div style={{ fontSize:10, fontWeight:700, color:"#7a95b0", textTransform:"uppercase", letterSpacing:"0.1em", marginBottom:4 }}>Croissance (TND)</div>
              <div style={{ fontSize:26, fontWeight:800, color:"#1a2b4a", letterSpacing:"-0.04em", lineHeight:1 }}>{((n-n1)/1000).toFixed(1)}<span style={{ fontSize:14, fontWeight:600, color:"#7a95b0", marginLeft:3 }}>K TND</span></div>
              <div style={{ marginTop:10, padding:"8px 10px", borderRadius:8, background:"rgba(201,168,76,0.08)", border:"1px solid rgba(201,168,76,0.2)" }}>
                <div style={{ fontSize:9, color:"#7a95b0", fontWeight:600, textTransform:"uppercase" }}>Différence absolue</div>
                <div style={{ fontSize:11, color:"#c9a84c", fontWeight:700 }}>{annee} − {annee-1} = +{((n-n1)/1000).toFixed(0)} K</div>
              </div>
            </div>

            {/* Card — Croissance % */}
            <div style={{ background: growthBg, borderRadius:16, padding:"18px 20px", border:`1px solid ${growthColor}33`, boxShadow:"0 2px 12px rgba(26,103,180,0.07)", position:"relative", overflow:"hidden" }}>
              <div style={{ position:"absolute", top:0, left:0, right:0, height:3, background:`linear-gradient(90deg,${growthColor},${growthColor}55)`, borderRadius:"16px 16px 0 0" }}/>
              <div style={{ width:36, height:36, borderRadius:10, background:`${growthColor}18`, display:"flex", alignItems:"center", justifyContent:"center", color:growthColor, marginBottom:12 }}><IconPercent /></div>
              <div style={{ fontSize:10, fontWeight:700, color:"#7a95b0", textTransform:"uppercase", letterSpacing:"0.1em", marginBottom:4 }}>Croissance %</div>
              <div style={{ fontSize:32, fontWeight:800, color:growthColor, letterSpacing:"-0.04em", lineHeight:1 }}>{isPos ? "+" : ""}{growth.toFixed(2)}<span style={{ fontSize:16 }}>%</span></div>
              <div style={{ marginTop:10, display:"flex", alignItems:"center", gap:6 }}>
                <span style={{ fontSize:20 }}>{isPos ? "📈" : "📉"}</span>
                <span style={{ fontSize:11, color:growthColor, fontWeight:700 }}>vs {annee-1}</span>
              </div>
            </div>

          </div>
        );
      })()}

      {/* YTD */}
      {ytd && (() => {
        const ytdN   = parseFloat(ytd.ytd_n||0);
        const ytdN1  = parseFloat(ytd.ytd_n1||0);
        const ytdGrowth = parseFloat(ytd.ytd_growth_pct||0);
        const isPos  = ytdGrowth >= 0;
        const growthColor = isPos ? "#1A6B3A" : "#C0392B";
        return (
          <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr 1fr", gap:16, marginBottom:16 }}>

            {/* YTD N */}
            <div style={{ background:"rgba(255,255,255,0.88)", borderRadius:16, padding:"16px 20px", border:"1px solid rgba(180,210,235,0.8)", boxShadow:"0 2px 12px rgba(26,103,180,0.07)", position:"relative", overflow:"hidden" }}>
              <div style={{ position:"absolute", top:0, left:0, right:0, height:3, background:"linear-gradient(90deg,#1a8fd1,#1a8fd155)", borderRadius:"16px 16px 0 0" }}/>
              <div style={{ display:"flex", justifyContent:"space-between", alignItems:"flex-start", marginBottom:10 }}>
                <div style={{ width:34, height:34, borderRadius:9, background:"rgba(26,143,209,0.1)", display:"flex", alignItems:"center", justifyContent:"center", color:"#1a8fd1" }}><IconCalendar /></div>
                <span style={{ fontSize:10, fontWeight:700, color:"#1a8fd1", background:"rgba(26,143,209,0.1)", border:"1px solid rgba(26,143,209,0.2)", borderRadius:99, padding:"2px 8px" }}>Mois {ytd.mois}</span>
              </div>
              <div style={{ fontSize:10, fontWeight:700, color:"#7a95b0", textTransform:"uppercase", letterSpacing:"0.1em", marginBottom:4 }}>YTD {annee}</div>
              <div style={{ fontSize:24, fontWeight:800, color:"#1a2b4a", letterSpacing:"-0.04em" }}>{(ytdN/1000000).toFixed(2)}<span style={{ fontSize:13, color:"#7a95b0", marginLeft:3 }}>M TND</span></div>
            </div>

            {/* YTD N-1 */}
            <div style={{ background:"rgba(255,255,255,0.88)", borderRadius:16, padding:"16px 20px", border:"1px solid rgba(180,210,235,0.8)", boxShadow:"0 2px 12px rgba(26,103,180,0.07)", position:"relative", overflow:"hidden" }}>
              <div style={{ position:"absolute", top:0, left:0, right:0, height:3, background:"linear-gradient(90deg,#0e9fce,#0e9fce55)", borderRadius:"16px 16px 0 0" }}/>
              <div style={{ display:"flex", justifyContent:"space-between", alignItems:"flex-start", marginBottom:10 }}>
                <div style={{ width:34, height:34, borderRadius:9, background:"rgba(14,159,206,0.1)", display:"flex", alignItems:"center", justifyContent:"center", color:"#0e9fce" }}><IconCalendarOld /></div>
                <span style={{ fontSize:10, fontWeight:700, color:"#0e9fce", background:"rgba(14,159,206,0.1)", border:"1px solid rgba(14,159,206,0.2)", borderRadius:99, padding:"2px 8px" }}>Même période</span>
              </div>
              <div style={{ fontSize:10, fontWeight:700, color:"#7a95b0", textTransform:"uppercase", letterSpacing:"0.1em", marginBottom:4 }}>YTD {annee-1}</div>
              <div style={{ fontSize:24, fontWeight:800, color:"#1a2b4a", letterSpacing:"-0.04em" }}>{(ytdN1/1000000).toFixed(2)}<span style={{ fontSize:13, color:"#7a95b0", marginLeft:3 }}>M TND</span></div>
            </div>

            {/* YTD Growth */}
            <div style={{ background: isPos ? "rgba(26,107,58,0.06)" : "rgba(192,57,43,0.06)", borderRadius:16, padding:"16px 20px", border:`1px solid ${growthColor}33`, boxShadow:"0 2px 12px rgba(26,103,180,0.07)", position:"relative", overflow:"hidden" }}>
              <div style={{ position:"absolute", top:0, left:0, right:0, height:3, background:`linear-gradient(90deg,${growthColor},${growthColor}55)`, borderRadius:"16px 16px 0 0" }}/>
              <div style={{ display:"flex", justifyContent:"space-between", alignItems:"flex-start", marginBottom:10 }}>
                <div style={{ width:34, height:34, borderRadius:9, background:`${growthColor}18`, display:"flex", alignItems:"center", justifyContent:"center", color:growthColor }}><IconBarChart /></div>
                <span style={{ fontSize:18 }}>{isPos ? "📈" : "📉"}</span>
              </div>
              <div style={{ fontSize:10, fontWeight:700, color:"#7a95b0", textTransform:"uppercase", letterSpacing:"0.1em", marginBottom:4 }}>Croissance YTD</div>
              <div style={{ fontSize:28, fontWeight:800, color:growthColor, letterSpacing:"-0.04em" }}>{isPos ? "+" : ""}{ytdGrowth.toFixed(2)}<span style={{ fontSize:14 }}>%</span></div>
              <div style={{ marginTop:6 }}>
                <div style={{ height:5, borderRadius:99, background:"rgba(180,210,235,0.3)" }}>
                  <div style={{ height:"100%", width:`${Math.min(Math.abs(ytdGrowth), 100)}%`, background:growthColor, borderRadius:99 }}/>
                </div>
              </div>
            </div>

          </div>
        );
      })()}

      <Section
        title="Dynamique mensuelle du chiffre d’affaires"
        subtitle="Analyse de l’évolution mensuelle et du cumul annuel du CA."
      />

      {/* 2. MENSUEL — merged dual-axis */}
      <div className="mb-4">
        <ChartCard title="Évolution mensuelle & cumul annuel du CA" accent="#c9a84c"
          subtitle="Barres colorées par saison · Ligne = cumul annuel"
        >
          {(() => {
            // Assign season color per month
            const MONTH_SEASON = {
              1:"Basse",2:"Basse",3:"Basse",4:"Moyenne",5:"Moyenne",
              6:"Haute",7:"Haute",8:"Haute",9:"Haute",10:"Moyenne",11:"Basse",12:"Basse"
            };
            const SEA_COLOR = { "Haute":"#1E3A5F", "Moyenne":"#2E86AB", "Basse":"#A8DADC" };
            const SEA_LABEL = { "Haute":"Haute saison ☀️", "Moyenne":"Moyenne saison 🌤️", "Basse":"Basse saison ❄️" };
            const maxVal = Math.max(...cumulData.map(r => parseFloat(r.ca_ttc || 0)));
            const enriched = cumulData.map(r => ({
              ...r,
              isPeak: parseFloat(r.ca_ttc) === maxVal,
            }));
            return (
              <div>
                {/* Season legend */}
                <div style={{ display:"flex", gap:16, marginBottom:8, paddingLeft:4 }}>
                  {Object.entries(SEA_LABEL).map(([k,v]) => (
                    <div key={k} style={{ display:"flex", alignItems:"center", gap:5 }}>
                      <span style={{ width:10, height:10, borderRadius:3, background:SEA_COLOR[k], display:"inline-block" }} />
                      <span style={{ fontSize:10, color:"#4a6080", fontWeight:600 }}>{v}</span>
                    </div>
                  ))}
                </div>
                <ResponsiveContainer width="100%" height={260}>
                  <ComposedChart data={enriched} margin={{ top:16, right:20, left:0, bottom:0 }} barSize={28}>
                    <defs>
                      <linearGradient id="gradCumul" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%"  stopColor="#c9a84c" stopOpacity={0.18} />
                        <stop offset="95%" stopColor="#c9a84c" stopOpacity={0} />
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" stroke="rgba(180,210,235,0.4)" vertical={false} />
                    <XAxis dataKey="mois_nom" tick={{ fontSize:10, fill:"#7a95b0" }} axisLine={false} tickLine={false} />
                    <YAxis yAxisId="bar" tickFormatter={v => `${(v/1000).toFixed(0)}K`} tick={{ fontSize:10, fill:"#7a95b0" }} axisLine={false} tickLine={false} />
                    <YAxis yAxisId="line" orientation="right" tickFormatter={v => `${(v/1000000).toFixed(1)}M`} tick={{ fontSize:10, fill:"#c9a84c" }} axisLine={false} tickLine={false} />
                    <Tooltip
                      contentStyle={tooltipStyle}
                      labelStyle={tooltipLabelStyle}
                      formatter={(v, name) => name === "CA Mensuel" ? [fmtTND(v), name] : [`${(v/1000000).toFixed(2)} M TND`, name]}
                    />
                    <Bar yAxisId="bar" dataKey="ca_ttc" name="CA Mensuel" radius={[5,5,0,0]}
                      label={{
                        position:"top",
                        formatter:(v, entry, idx) => enriched[idx]?.isPeak ? "🏆" : "",
                        fontSize:14,
                      }}
                    >
                      {enriched.map((r, i) => {
                        const moisNum = i + 1;
                        const sea = MONTH_SEASON[moisNum] || "Basse";
                        return <Cell key={i} fill={SEA_COLOR[sea]} opacity={r.isPeak ? 1 : 0.82} />;
                      })}
                    </Bar>
                    <Area yAxisId="line" type="monotone" dataKey="ca_cumul_calc" name="Cumul annuel"
                      stroke="#c9a84c" strokeWidth={2.5} fill="url(#gradCumul)"
                      dot={false} activeDot={{ r:5, fill:"#c9a84c", stroke:"#fff", strokeWidth:2 }}
                    />
                  </ComposedChart>
                </ResponsiveContainer>
              </div>
            );
          })()}
        </ChartCard>
      </div>

      <Section
        title={`Comparaison ${annee} vs ${annee - 1}`}
        subtitle="Mise en perspective de la performance annuelle mois par mois."
      />

      {/* 3. COMPARAISON N vs N-1 — merged chart + upgraded table */}
      <div className="mb-4">
        <ChartCard title={`CA mensuel ${annee} vs ${annee-1} · Croissance %`}
          subtitle="Barres = CA par année · Ligne = taux de croissance mensuel"
        >
          {(() => {
            const posGrowth = compar.filter(r => parseFloat(r.growth_rate) >= 0).length;
            const negGrowth = compar.filter(r => parseFloat(r.growth_rate) < 0).length;
            const avgGrowth = compar.length > 0
              ? (compar.reduce((s,r) => s + parseFloat(r.growth_rate||0), 0) / compar.length).toFixed(1)
              : 0;
            return (
              <div>
                {/* Summary pills */}
                <div style={{ display:"flex", gap:10, marginBottom:10 }}>
                  <div style={{ background:"rgba(26,107,58,0.08)", border:"1px solid rgba(26,107,58,0.2)", borderRadius:99, padding:"3px 10px", fontSize:10, fontWeight:700, color:"#1A6B3A" }}>
                    ↑ {posGrowth} mois en hausse
                  </div>
                  <div style={{ background:"rgba(192,57,43,0.08)", border:"1px solid rgba(192,57,43,0.2)", borderRadius:99, padding:"3px 10px", fontSize:10, fontWeight:700, color:"#C0392B" }}>
                    ↓ {negGrowth} mois en baisse
                  </div>
                  <div style={{ background:"rgba(26,143,209,0.08)", border:"1px solid rgba(26,143,209,0.2)", borderRadius:99, padding:"3px 10px", fontSize:10, fontWeight:700, color:"#1a8fd1" }}>
                    ∅ croissance moy. {avgGrowth}%
                  </div>
                </div>
                <ResponsiveContainer width="100%" height={260}>
                  <ComposedChart data={compar} margin={{ top:10, right:24, left:0, bottom:0 }} barSize={14}>
                    <defs>
                      <linearGradient id="gradN" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="0%" stopColor="#1E3A5F" stopOpacity={0.9} />
                        <stop offset="100%" stopColor="#1E3A5F" stopOpacity={0.6} />
                      </linearGradient>
                      <linearGradient id="gradN1" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="0%" stopColor="#A8DADC" stopOpacity={0.9} />
                        <stop offset="100%" stopColor="#A8DADC" stopOpacity={0.5} />
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" stroke="rgba(180,210,235,0.4)" vertical={false} />
                    <XAxis dataKey="mois_nom" tick={{ fontSize:10, fill:"#7a95b0" }} axisLine={false} tickLine={false} />
                    <YAxis yAxisId="bar" tickFormatter={v => `${(v/1000).toFixed(0)}K`} tick={{ fontSize:10, fill:"#7a95b0" }} axisLine={false} tickLine={false} />
                    <YAxis yAxisId="growth" orientation="right" tickFormatter={v => `${v}%`} tick={{ fontSize:10, fill:"#7a95b0" }} axisLine={false} tickLine={false} domain={["auto","auto"]} />
                    <Tooltip
                      contentStyle={tooltipStyle}
                      labelStyle={tooltipLabelStyle}
                      formatter={(v, name) => {
                        if (name === "Croissance %") return [`${parseFloat(v).toFixed(1)}%`, name];
                        return [fmtTND(v), name];
                      }}
                    />
                    <Legend wrapperStyle={{ fontSize:11, paddingTop:8 }} />
                    <Bar yAxisId="bar" dataKey="ca_n" name={String(annee)} fill="url(#gradN)" radius={[4,4,0,0]} />
                    <Bar yAxisId="bar" dataKey="ca_n1" name={String(annee-1)} fill="url(#gradN1)" radius={[4,4,0,0]} />
                    <Line yAxisId="growth" type="monotone" dataKey="growth_rate" name="Croissance %"
                      strokeWidth={2.5} dot={{ r:4, strokeWidth:2 }} activeDot={{ r:6, stroke:"#fff", strokeWidth:2 }}
                      stroke="#c9a84c"
                    >
                      {compar.map((entry, i) => (
                        <Cell key={i} stroke={parseFloat(entry.growth_rate) >= 0 ? "#1A6B3A" : "#C0392B"} />
                      ))}
                    </Line>
                  </ComposedChart>
                </ResponsiveContainer>
              </div>
            );
          })()}
        </ChartCard>
      </div>

      {/* Tableau comparaison — upgraded */}
      <ChartCard
        title="Comparaison mensuelle détaillée"
        subtitle="Lecture détaillée des écarts de CA et des taux de croissance."
        className="mb-4"
      >
        <div className="overflow-x-auto">
          <table className="w-full text-xs">
            <thead>
              <tr className="bg-[#1E3A5F] text-white">
                <th className="p-2 text-left rounded-tl-lg">Mois</th>
                <th className="p-2 text-left">Saison</th>
                <th className="p-2 text-right">CA {annee}</th>
                <th className="p-2 text-right">CA {annee-1}</th>
                <th className="p-2 text-right">Écart</th>
                <th className="p-2 text-right">Évolution</th>
                <th className="p-2 text-right rounded-tr-lg">Croissance %</th>
              </tr>
            </thead>
            <tbody>
              {compar.map((r, i) => {
                const diff = parseFloat(r.diff_absolue || 0);
                const growth = parseFloat(r.growth_rate || 0);
                const isPos = diff >= 0;
                const SAISON_ICON = { "Haute":"☀️", "Moyenne":"🌤️", "Basse":"❄️" };
                const maxCA = Math.max(...compar.map(x => parseFloat(x.ca_n || 0)));
                const barW = maxCA > 0 ? (parseFloat(r.ca_n) / maxCA * 100).toFixed(0) : 0;
                return (
                  <tr key={i} className={i % 2 === 0 ? "bg-white" : "bg-gray-50"} style={{ borderBottom:"1px solid rgba(180,210,235,0.3)" }}>
                    <td className="p-2 font-semibold text-[#1E3A5F]">{r.mois_nom}</td>
                    <td className="p-2">
                      <span style={{ fontSize:11 }}>{SAISON_ICON[r.saison] || "📅"}</span>
                      <span style={{ fontSize:9, color:"#7a95b0", marginLeft:3 }}>{r.saison}</span>
                    </td>
                    <td className="p-2 text-right">
                      <div style={{ fontWeight:700, color:"#1E3A5F", fontFamily:"monospace" }}>{fmt(r.ca_n)}</div>
                      <div style={{ height:3, borderRadius:99, background:"rgba(30,58,95,0.12)", marginTop:2 }}>
                        <div style={{ height:"100%", width:`${barW}%`, background:"#1E3A5F", borderRadius:99 }} />
                      </div>
                    </td>
                    <td className="p-2 text-right font-mono text-gray-400">{fmt(r.ca_n1)}</td>
                    <td className={`p-2 text-right font-mono font-semibold ${isPos ? "text-green-600" : "text-red-500"}`}>
                      {isPos ? "+" : ""}{fmt(r.diff_absolue)}
                    </td>
                    <td className="p-2 text-right">
                      <div style={{ display:"flex", alignItems:"center", justifyContent:"flex-end", gap:4 }}>
                        <span style={{ fontSize:14 }}>{isPos ? "📈" : "📉"}</span>
                      </div>
                    </td>
                    <td className="p-2 text-right"><Badge value={r.growth_rate} /></td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </ChartCard>

      <Section
        title="Lecture trimestrielle et saisonnière"
        subtitle="Vision consolidée par trimestre et par saison touristique."
      />

      {/* 4. TRIMESTRIEL & SAISONNIER */}
      <div className="grid grid-cols-3 gap-4 mb-4">
        <ChartCard title="Performance trimestrielle" subtitle="CA et cumul par trimestre" className="col-span-2">
          {(() => {
            const TRIM_COLORS  = ["#A8DADC","#2E86AB","#1E3A5F","#2E86AB"];
            const TRIM_LABELS  = { "T1":"Hiver·Printemps","T2":"Printemps·Été","T3":"Été·Automne","T4":"Automne·Hiver" };
            const TRIM_ICONS   = { "T1":"❄️","T2":"🌸","T3":"☀️","T4":"🍂" };
            const maxCA = Math.max(...trim.map(r => parseFloat(r.ca_total||0)));
            const total = trim.reduce((s,r) => s + parseFloat(r.ca_total||0), 0);
            return (
              <div>
                {/* Mini KPI cards row */}
                <div style={{ display:"grid", gridTemplateColumns:"repeat(4,1fr)", gap:8, marginBottom:12 }}>
                  {trim.map((r,i) => {
                    const pct = total > 0 ? (parseFloat(r.ca_total)/total*100).toFixed(1) : 0;
                    const color = TRIM_COLORS[i % TRIM_COLORS.length];
                    const isPeak = parseFloat(r.ca_total) === maxCA;
                    return (
                      <div key={i} style={{ background: isPeak ? `rgba(30,58,95,0.07)` : "rgba(180,210,235,0.12)", borderRadius:10, padding:"8px 10px", border:`1px solid ${color}33`, position:"relative" }}>
                        {isPeak && <div style={{ position:"absolute", top:4, right:6, fontSize:10 }}>🏆</div>}
                        <div style={{ fontSize:11 }}>{TRIM_ICONS[r.trimestre] || "📅"}</div>
                        <div style={{ fontSize:10, fontWeight:700, color, marginTop:2 }}>{r.trimestre}</div>
                        <div style={{ fontSize:9, color:"#7a95b0", marginBottom:4 }}>{TRIM_LABELS[r.trimestre] || ""}</div>
                        <div style={{ fontSize:13, fontWeight:800, color:"#1E3A5F" }}>{(parseFloat(r.ca_total)/1000000).toFixed(2)}M</div>
                        <div style={{ fontSize:9, color, fontWeight:700 }}>{pct}% du total</div>
                        <div style={{ height:3, borderRadius:99, background:"rgba(180,210,235,0.4)", marginTop:5 }}>
                          <div style={{ height:"100%", width:`${maxCA>0?(parseFloat(r.ca_total)/maxCA*100):0}%`, background:color, borderRadius:99 }} />
                        </div>
                      </div>
                    );
                  })}
                </div>
                {/* Combined bar + cumul line */}
                <ResponsiveContainer width="100%" height={180}>
                  <ComposedChart data={trim} margin={{ top:4, right:20, left:0, bottom:0 }} barSize={40}>
                    <defs>
                      <linearGradient id="gradCumulTrim" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="0%" stopColor="#c9a84c" stopOpacity={0.15}/>
                        <stop offset="100%" stopColor="#c9a84c" stopOpacity={0}/>
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" stroke="rgba(180,210,235,0.4)" vertical={false}/>
                    <XAxis dataKey="trimestre" tick={{ fontSize:11, fill:"#7a95b0" }} axisLine={false} tickLine={false}/>
                    <YAxis yAxisId="bar" tickFormatter={v=>`${(v/1000000).toFixed(1)}M`} tick={{ fontSize:10, fill:"#7a95b0" }} axisLine={false} tickLine={false}/>
                    <YAxis yAxisId="cumul" orientation="right" tickFormatter={v=>`${(v/1000000).toFixed(1)}M`} tick={{ fontSize:10, fill:"#c9a84c" }} axisLine={false} tickLine={false}/>
                    <Tooltip contentStyle={tooltipStyle} labelStyle={tooltipLabelStyle} formatter={(v,name) => [fmtTND(v), name]}/>
                    <Bar yAxisId="bar" dataKey="ca_total" name="CA Trimestre" radius={[6,6,0,0]}>
                      {trim.map((_,i) => <Cell key={i} fill={TRIM_COLORS[i % TRIM_COLORS.length]}/>)}
                    </Bar>
                    <Area yAxisId="cumul" type="monotone" dataKey="ca_cumul" name="Cumul" stroke="#c9a84c" strokeWidth={2.5} fill="url(#gradCumulTrim)" dot={{ r:4, fill:"#c9a84c", stroke:"#fff", strokeWidth:2 }} activeDot={{ r:6 }}/>
                  </ComposedChart>
                </ResponsiveContainer>
              </div>
            );
          })()}
        </ChartCard>

        <ChartCard title="Répartition saisonnière">
          {(() => {
            const SAISON_CONFIG = {
              "Haute":   { icon: "☀️", label: "Haute saison",   desc: "Été — pic d'activité",   color: "#1E3A5F", bg: "rgba(30,58,95,0.07)"  },
              "Moyenne": { icon: "🌤️", label: "Moyenne saison", desc: "Printemps / Automne",    color: "#2E86AB", bg: "rgba(46,134,171,0.07)" },
              "Basse":   { icon: "❄️", label: "Basse saison",   desc: "Hiver — creux annuel",  color: "#A8DADC", bg: "rgba(168,218,220,0.25)" },
            };
            const total = saison.reduce((s, r) => s + parseFloat(r.ca_total || 0), 0);
            const sorted = [...saison].sort((a, b) => parseFloat(b.ca_total) - parseFloat(a.ca_total));
            return (
              <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
                {sorted.map((r, i) => {
                  const pct = total > 0 ? (parseFloat(r.ca_total) / total) * 100 : 0;
                  const cfg = SAISON_CONFIG[r.saison] || { icon: "📅", label: r.saison, desc: "", color: "#1E3A5F", bg: "rgba(30,58,95,0.07)" };
                  return (
                    <div key={i} style={{ background: cfg.bg, borderRadius: 10, padding: "10px 12px", border: `1px solid ${cfg.color}22` }}>
                      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 6 }}>
                        <div style={{ display: "flex", alignItems: "center", gap: 7 }}>
                          <span style={{ fontSize: 18 }}>{cfg.icon}</span>
                          <div>
                            <div style={{ fontSize: 11, fontWeight: 700, color: cfg.color }}>{cfg.label}</div>
                            <div style={{ fontSize: 9, color: "#7a95b0" }}>{cfg.desc}</div>
                          </div>
                        </div>
                        <div style={{ textAlign: "right" }}>
                          <div style={{ fontSize: 13, fontWeight: 800, color: cfg.color }}>{pct.toFixed(1)}%</div>
                          <div style={{ fontSize: 9, color: "#7a95b0" }}>{(parseFloat(r.ca_total)/1000000).toFixed(2)} M TND</div>
                        </div>
                      </div>
                      <div style={{ height: 6, borderRadius: 99, background: "rgba(180,210,235,0.35)" }}>
                        <div style={{ height: "100%", width: `${pct}%`, background: cfg.color, borderRadius: 99, transition: "width 0.6s ease" }} />
                      </div>
                    </div>
                  );
                })}
              </div>
            );
          })()}
        </ChartCard>
      </div>

      {/* Tableau trimestriel */}
      <div className="grid grid-cols-2 gap-4 mb-4">
        <ChartCard
          title="Détail trimestriel du CA"
          subtitle="Montants et cumul du chiffre d’affaires par trimestre."
        >
          <table className="w-full text-xs">
            <thead>
              <tr className="bg-[#1E3A5F] text-white">
                <th className="p-2 text-left rounded-tl-lg">Trimestre</th>
                <th className="p-2 text-right">CA (TND)</th>
                <th className="p-2 text-right rounded-tr-lg">Cumul (TND)</th>
              </tr>
            </thead>
            <tbody>
              {trim.map((r, i) => (
                <tr key={i} className={i % 2 === 0 ? "bg-white" : "bg-gray-50"}>
                  <td className="p-2 font-bold text-[#1E3A5F]">{r.trimestre}</td>
                  <td className="p-2 text-right font-mono">{fmt(r.ca_total)}</td>
                  <td className="p-2 text-right font-mono text-[#2E86AB]">{fmt(r.ca_cumul)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </ChartCard>

        <ChartCard
          title="Détail saisonnier du CA"
          subtitle="Répartition du CA par saison et contribution en pourcentage."
        >
          <table className="w-full text-xs">
            <thead>
              <tr className="bg-[#1E3A5F] text-white">
                <th className="p-2 text-left rounded-tl-lg">Saison</th>
                <th className="p-2 text-right">CA (TND)</th>
                <th className="p-2 text-right rounded-tr-lg">Part %</th>
              </tr>
            </thead>
            <tbody>
              {saison.map((r, i) => (
                <tr key={i} className={i % 2 === 0 ? "bg-white" : "bg-gray-50"}>
                  <td className="p-2 font-bold" style={{ color: SAISON_COLORS[r.saison] || "#1E3A5F" }}>{r.saison}</td>
                  <td className="p-2 text-right font-mono">{fmt(r.ca_total)}</td>
                  <td className="p-2 text-right font-semibold text-[#1E3A5F]">{r.part_pct}%</td>
                </tr>
              ))}
            </tbody>
          </table>
        </ChartCard>
      </div>

      <Section
        title="Analyse par catégories de revenus"
        subtitle="Contribution des différentes lignes de revenus au chiffre d’affaires global."
      />

      {/* 5. CATÉGORIES — full width clean redesign */}
      <ChartCard title="Répartition du CA par catégorie de revenus" subtitle="Part du total · CA TTC · CA HT · TVA implicite">
        {(() => {
          const CAT_COLORS = ["#1E3A5F","#2E86AB","#F4A261","#E63946"];
          const total = categ.reduce((s, r) => s + parseFloat(r.ca_ttc_total||0), 0);
          const sorted = [...categ].sort((a,b) => parseFloat(b.ca_ttc_total) - parseFloat(a.ca_ttc_total));
          // build donut
          let cumul = 0;
          const stops = sorted.map((r,i) => {
            const pct = total > 0 ? (parseFloat(r.ca_ttc_total)/total)*100 : 0;
            const from = cumul; cumul += pct;
            return `${CAT_COLORS[i % CAT_COLORS.length]} ${from.toFixed(2)}% ${cumul.toFixed(2)}%`;
          });
          const gradient = `conic-gradient(from 90deg, ${stops.join(", ")})`;
          return (
            <div style={{ display:"flex", gap:32, alignItems:"flex-start" }}>

              {/* LEFT — donut */}
              <div style={{ display:"flex", flexDirection:"column", alignItems:"center", gap:12, flexShrink:0 }}>
                <div style={{ position:"relative", width:160, height:160 }}>
                  <div style={{ width:160, height:160, borderRadius:"50%", background:gradient }}/>
                  <div style={{
                    position:"absolute", top:"50%", left:"50%", transform:"translate(-50%,-50%)",
                    width:96, height:96, borderRadius:"50%", background:"white",
                    display:"flex", flexDirection:"column", alignItems:"center", justifyContent:"center",
                    boxShadow:"0 0 0 1px rgba(180,210,235,0.5)"
                  }}>
                    <div style={{ fontSize:8, color:"#7a95b0", fontWeight:700, textTransform:"uppercase", letterSpacing:"0.06em" }}>Total CA</div>
                    <div style={{ fontSize:15, fontWeight:800, color:"#1E3A5F" }}>{(total/1000000).toFixed(2)}M</div>
                    <div style={{ fontSize:8, color:"#7a95b0" }}>TND TTC</div>
                  </div>
                </div>
                {/* donut legend */}
                <div style={{ display:"flex", flexDirection:"column", gap:5 }}>
                  {sorted.map((r,i) => {
                    const pct = total > 0 ? (parseFloat(r.ca_ttc_total)/total*100).toFixed(1) : 0;
                    return (
                      <div key={i} style={{ display:"flex", alignItems:"center", gap:6 }}>
                        <span style={{ width:10, height:10, borderRadius:"50%", background:CAT_COLORS[i%CAT_COLORS.length], display:"inline-block", flexShrink:0 }}/>
                        <span style={{ fontSize:11, color:"#4a6080", fontWeight:600, textTransform:"capitalize", minWidth:70 }}>{r.categorie}</span>
                        <span style={{ fontSize:11, fontWeight:800, color:CAT_COLORS[i%CAT_COLORS.length] }}>{pct}%</span>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* RIGHT — category rows */}
              <div style={{ flex:1, display:"flex", flexDirection:"column", gap:8 }}>
                {sorted.map((r,i) => {
                  const ttc  = parseFloat(r.ca_ttc_total||0);
                  const ht   = parseFloat(r.ca_ht_total||0);
                  const tva  = ttc > 0 ? ((ttc-ht)/ttc*100).toFixed(1) : 0;
                  const pct  = total > 0 ? (ttc/total*100) : 0;
                  const color = CAT_COLORS[i%CAT_COLORS.length];
                  return (
                    <div key={i} style={{
                      display:"flex", alignItems:"center", gap:14,
                      background:"rgba(255,255,255,0.7)", borderRadius:12, padding:"12px 16px",
                      border:`1px solid ${color}28`, boxShadow:"0 1px 4px rgba(26,103,180,0.05)"
                    }}>
                      {/* color dot + name */}
                      <div style={{ display:"flex", alignItems:"center", gap:8, minWidth:110 }}>
                        <span style={{ width:12, height:12, borderRadius:"50%", background:color, display:"inline-block", flexShrink:0 }}/>
                        <span style={{ fontSize:12, fontWeight:700, color:"#1E3A5F", textTransform:"capitalize" }}>{r.categorie}</span>
                      </div>
                      {/* progress bar */}
                      <div style={{ flex:1, height:8, borderRadius:99, background:"rgba(180,210,235,0.3)" }}>
                        <div style={{ height:"100%", width:`${Math.max(pct,0.5)}%`, background:color, borderRadius:99 }}/>
                      </div>
                      {/* metrics */}
                      <div style={{ display:"flex", gap:20, flexShrink:0 }}>
                        <div style={{ textAlign:"right" }}>
                          <div style={{ fontSize:9, color:"#7a95b0", fontWeight:600, textTransform:"uppercase" }}>CA TTC</div>
                          <div style={{ fontSize:13, fontWeight:800, color:"#1E3A5F" }}>{(ttc/1000000).toFixed(3)}M</div>
                        </div>
                        <div style={{ textAlign:"right" }}>
                          <div style={{ fontSize:9, color:"#7a95b0", fontWeight:600, textTransform:"uppercase" }}>CA HT</div>
                          <div style={{ fontSize:13, fontWeight:700, color:"#2E86AB" }}>{(ht/1000000).toFixed(3)}M</div>
                        </div>
                        <div style={{ textAlign:"right" }}>
                          <div style={{ fontSize:9, color:"#7a95b0", fontWeight:600, textTransform:"uppercase" }}>TVA</div>
                          <div style={{ fontSize:13, fontWeight:700, color:"#c9a84c" }}>{tva}%</div>
                        </div>
                        <div style={{ textAlign:"right", minWidth:42 }}>
                          <div style={{ fontSize:9, color:"#7a95b0", fontWeight:600, textTransform:"uppercase" }}>Part</div>
                          <div style={{ fontSize:13, fontWeight:800, color }}>{pct.toFixed(1)}%</div>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          );
        })()}
      </ChartCard>

      {/* Tableau catégories */}
      <ChartCard
        title="Détail par catégorie de revenus"
        subtitle="Vue tabulaire détaillée des montants et parts par catégorie."
        className="mt-4"
      >
        <table className="w-full text-sm">
          <thead>
            <tr className="bg-[#1E3A5F] text-white">
              <th className="p-3 text-left rounded-tl-lg">Catégorie</th>
              <th className="p-3 text-right">CA TTC (TND)</th>
              <th className="p-3 text-right">CA HT (TND)</th>
              <th className="p-3 text-right rounded-tr-lg">Part %</th>
            </tr>
          </thead>
          <tbody>
            {categ.map((r, i) => (
              <tr key={i} className={i % 2 === 0 ? "bg-white" : "bg-gray-50"} style={{ borderBottom:"1px solid rgba(180,210,235,0.3)" }}>
                <td className="p-3 font-semibold text-[#1E3A5F] capitalize">{r.categorie}</td>
                <td className="p-3 text-right font-mono font-bold">{fmt(r.ca_ttc_total)}</td>
                <td className="p-3 text-right font-mono text-gray-400">{fmt(r.ca_ht_total)}</td>
                <td className="p-3 text-right font-semibold" style={{ color:"#1E3A5F" }}>{r.part_pct}%</td>
              </tr>
            ))}
          </tbody>
        </table>
      </ChartCard>

    </div>
  );
}
