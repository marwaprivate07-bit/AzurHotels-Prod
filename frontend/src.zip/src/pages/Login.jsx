import { useState, useEffect, useRef } from "react";
import axios from "axios";

const C = {
  sapphire:   "#3C6070",
  royalBlue:  "#112250",
  royalMid:   "#1a3568",
  quicksand:  "#E0C58F",
  swanWing:   "#F5F0E9",
  shellstone: "#D8CCB1",
  quickDim:   "rgba(224,197,143,0.55)",
  quickGlow:  "rgba(224,197,143,0.22)",
};

// ── Blue Iridescent WebGL ─────────────────────────────────────────────────────
function IridescentBackground() {
  const canvasRef = useRef(null);
  const mouseRef  = useRef({ x: 0.5, y: 0.5 });

  useEffect(() => {
    const canvas = canvasRef.current;
    const gl = canvas.getContext("webgl") || canvas.getContext("experimental-webgl");
    if (!gl) return;

    const resize = () => {
      canvas.width  = window.innerWidth;
      canvas.height = window.innerHeight;
      gl.viewport(0, 0, canvas.width, canvas.height);
    };
    resize();
    window.addEventListener("resize", resize);

    const onMove = e => {
      mouseRef.current = {
        x: e.clientX / window.innerWidth,
        y: 1.0 - e.clientY / window.innerHeight,
      };
    };
    window.addEventListener("mousemove", onMove);

    const vert = `attribute vec2 a_pos; void main(){ gl_Position=vec4(a_pos,0.,1.); }`;

    const frag = `
      precision highp float;
      uniform float u_time;
      uniform vec2  u_res;
      uniform vec2  u_mouse;

      float hash(vec2 p){ return fract(sin(dot(p,vec2(127.1,311.7)))*43758.5453); }
      float noise(vec2 p){
        vec2 i=floor(p),f=fract(p),u=f*f*(3.-2.*f);
        return mix(mix(hash(i),hash(i+vec2(1,0)),u.x),
                   mix(hash(i+vec2(0,1)),hash(i+vec2(1,1)),u.x),u.y);
      }
      float fbm(vec2 p){
        float v=0.,a=.5;
        mat2 rot=mat2(cos(.5),sin(.5),-sin(.5),cos(.5));
        for(int i=0;i<7;i++){ v+=a*noise(p); p=rot*p*2.1+vec2(1.7,9.2); a*=.48; }
        return v;
      }

      // PURE BLUE diagonal gradient palette — no purple, no mauve
      vec3 bluePalette(float t){
        // navy deep → royal blue → sapphire → teal → icy cyan → back
        vec3 col = vec3(0.);

        // 1. deep navy (dark base)
        col += vec3(0.04, 0.09, 0.28) * smoothstep(0.0,  0.18, t) * smoothstep(0.35, 0.18, t);
        // 2. royal blue
        col += vec3(0.12, 0.24, 0.72) * smoothstep(0.12, 0.35, t) * smoothstep(0.58, 0.35, t);
        // 3. medium sapphire
        col += vec3(0.20, 0.42, 0.78) * smoothstep(0.28, 0.50, t) * smoothstep(0.72, 0.50, t);
        // 4. sapphire-teal
        col += vec3(0.18, 0.58, 0.82) * smoothstep(0.44, 0.64, t) * smoothstep(0.85, 0.64, t);
        // 5. teal / cyan
        col += vec3(0.28, 0.78, 0.88) * smoothstep(0.60, 0.78, t) * smoothstep(1.00, 0.78, t);
        // 6. icy light blue (near-white shimmer)
        col += vec3(0.72, 0.88, 0.98) * smoothstep(0.74, 0.90, t) * smoothstep(1.05, 0.90, t);
        // wrap back to deep navy
        col += vec3(0.04, 0.09, 0.28) * smoothstep(0.88, 1.00, t);

        return clamp(col, 0., 1.);
      }

      void main(){
        vec2 uv = gl_FragCoord.xy / u_res;
        float t  = u_time * 0.12;

        // mouse influence
        vec2 mOff = (u_mouse - 0.5) * 0.30;

        // domain warp — 2 levels for silky bands
        vec2 q = vec2(
          fbm(uv + vec2(0.0,0.0) + t*0.5  + mOff),
          fbm(uv + vec2(5.2,1.3) + t*0.4)
        );
        vec2 r = vec2(
          fbm(uv + q + vec2(1.7, 9.2) + t*0.35 + mOff*0.55),
          fbm(uv + q + vec2(8.3, 2.8) + t*0.30)
        );

        float f = fbm(uv + r + mOff*0.35);

        // diagonal silky bands — the signature React Bits look
        float band1 = sin((uv.x - uv.y)*4.0 + f*4.5 + t*1.1 + mOff.x*2.0) * 0.5 + 0.5;
        float band2 = sin((uv.x + uv.y)*3.2 - f*3.8 + t*0.8 + mOff.y*1.8) * 0.5 + 0.5;
        float band3 = sin( uv.x          *4.8 + r.x*5.2 + t*0.65)           * 0.5 + 0.5;

        float driver = fract((f*0.42 + band1*0.30 + band2*0.18 + band3*0.10) * 1.12);

        // slight mouse-driven hue shift (stays in blue range)
        float mouseShift = (u_mouse.x - 0.5) * 0.06;

        vec3 col = bluePalette(fract(driver + mouseShift));

        // depth variation
        col *= 0.80 + 0.26 * fbm(uv*2.2 + t*0.18);

        // very subtle warm gold shimmer on brightest highlights only
        float goldMask = smoothstep(0.82, 1.0, band1 * band2);
        col = mix(col, vec3(0.88, 0.78, 0.56), goldMask * 0.07);

        // brighten — matches screenshot luminosity
        col = pow(col, vec3(0.72));
        col = clamp(col * 1.1, 0., 1.);

        // soft edge vignette only
        vec2 vig = (uv - 0.5) * 1.7;
        col *= mix(0.65, 1.0, clamp(1. - dot(vig,vig), 0., 1.));

        gl_FragColor = vec4(col, 1.0);
      }
    `;

    const mk = (type, src) => {
      const s = gl.createShader(type);
      gl.shaderSource(s, src); gl.compileShader(s);
      if (!gl.getShaderParameter(s, gl.COMPILE_STATUS)) console.error(gl.getShaderInfoLog(s));
      return s;
    };
    const prog = gl.createProgram();
    gl.attachShader(prog, mk(gl.VERTEX_SHADER, vert));
    gl.attachShader(prog, mk(gl.FRAGMENT_SHADER, frag));
    gl.linkProgram(prog); gl.useProgram(prog);

    const buf = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, buf);
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1,-1,1,-1,-1,1,1,1]), gl.STATIC_DRAW);
    const loc = gl.getAttribLocation(prog,"a_pos");
    gl.enableVertexAttribArray(loc);
    gl.vertexAttribPointer(loc,2,gl.FLOAT,false,0,0);

    const uT = gl.getUniformLocation(prog,"u_time");
    const uR = gl.getUniformLocation(prog,"u_res");
    const uM = gl.getUniformLocation(prog,"u_mouse");

    let sm = { x:0.5, y:0.5 };
    let raf; const t0 = performance.now();

    const render = () => {
      sm.x += (mouseRef.current.x - sm.x) * 0.04;
      sm.y += (mouseRef.current.y - sm.y) * 0.04;
      gl.uniform1f(uT, (performance.now()-t0)/1000);
      gl.uniform2f(uR, canvas.width, canvas.height);
      gl.uniform2f(uM, sm.x, sm.y);
      gl.drawArrays(gl.TRIANGLE_STRIP, 0, 4);
      raf = requestAnimationFrame(render);
    };
    render();

    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener("resize", resize);
      window.removeEventListener("mousemove", onMove);
    };
  }, []);

  return <canvas ref={canvasRef} style={{ position:"fixed",inset:0,width:"100%",height:"100%",zIndex:0 }}/>;
}

// ── Golden Cursor ─────────────────────────────────────────────────────────────
function GoldenCursor() {
  const dotRef  = useRef(null);
  const ringRef = useRef(null);
  const pos  = useRef({ x:0,y:0 });
  const ring = useRef({ x:0,y:0 });

  useEffect(() => {
    const move = e => { pos.current = { x:e.clientX, y:e.clientY }; };
    window.addEventListener("mousemove", move);
    let raf;
    const tick = () => {
      ring.current.x += (pos.current.x - ring.current.x) * 0.11;
      ring.current.y += (pos.current.y - ring.current.y) * 0.11;
      if (dotRef.current)
        dotRef.current.style.transform  = `translate(${pos.current.x-4}px,${pos.current.y-4}px)`;
      if (ringRef.current)
        ringRef.current.style.transform = `translate(${ring.current.x-18}px,${ring.current.y-18}px)`;
      raf = requestAnimationFrame(tick);
    };
    tick();
    return () => { cancelAnimationFrame(raf); window.removeEventListener("mousemove",move); };
  }, []);

  return (
    <>
      <div ref={dotRef} style={{ position:"fixed",top:0,left:0,zIndex:9999,pointerEvents:"none", width:"8px",height:"8px",borderRadius:"50%",background:C.quicksand, boxShadow:`0 0 12px 4px rgba(224,197,143,0.75)` }}/>
      <div ref={ringRef} style={{ position:"fixed",top:0,left:0,zIndex:9998,pointerEvents:"none", width:"36px",height:"36px",borderRadius:"50%", border:`1.5px solid rgba(224,197,143,0.5)`, boxShadow:`0 0 10px rgba(224,197,143,0.22)` }}/>
    </>
  );
}

// ── Global Styles ─────────────────────────────────────────────────────────────
function GlobalStyles() {
  useEffect(() => {
    const el = document.createElement("style");
    el.textContent = `
      @import url('https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,300;0,400;0,500;1,400&family=Outfit:wght@300;400;500;600;700&display=swap');
      *{box-sizing:border-box;margin:0;padding:0;}
      body{background:#060f28;cursor:none;}
      a,button,input,label,select{cursor:none !important;}

      @keyframes shimmer{0%{background-position:-300% center;}100%{background-position:300% center;}}
      @keyframes fadeUp{from{opacity:0;transform:translateY(28px);}to{opacity:1;transform:translateY(0);}}
      @keyframes shake{0%,100%{transform:translateX(0);}15%,55%{transform:translateX(-8px);}35%,75%{transform:translateX(8px);}}
      @keyframes spin{to{transform:rotate(360deg);}}
      @keyframes successPop{0%{transform:scale(.97);opacity:.85;}60%{transform:scale(1.02);}100%{transform:scale(1);opacity:1;}}
      @keyframes checkDraw{from{stroke-dashoffset:50;}to{stroke-dashoffset:0;}}
      @keyframes quickPulse{
        0%,100%{box-shadow:0 0 28px rgba(224,197,143,0.2),0 14px 44px rgba(0,0,0,0.45);}
        50%    {box-shadow:0 0 52px rgba(224,197,143,0.42),0 14px 44px rgba(0,0,0,0.45);}
      }
      @keyframes floatUp{0%,100%{transform:translateY(0);}50%{transform:translateY(-7px);}}

      .login-card{animation:fadeUp .75s cubic-bezier(.22,1,.36,1) both;}
      .login-card.shake  {animation:shake .5s ease-in-out;}
      .login-card.success{animation:successPop .45s cubic-bezier(.22,1,.36,1) both;}
      .check-path{stroke-dasharray:50;stroke-dashoffset:50;animation:checkDraw .4s ease .1s both;}

      .connect-btn:not(:disabled):hover{
        transform:translateY(-2px) !important;
        box-shadow:0 16px 48px rgba(224,197,143,0.52) !important;
      }
      .connect-btn:not(:disabled):active{transform:translateY(0) !important;}

      input:-webkit-autofill,input:-webkit-autofill:hover,input:-webkit-autofill:focus{
        -webkit-box-shadow:0 0 0 1000px rgba(8,14,40,0.97) inset !important;
        -webkit-text-fill-color:#F5F0E9 !important;
        caret-color:#F5F0E9 !important;
      }
      ::placeholder{color:rgba(216,204,177,0.22) !important;}
    `;
    document.head.appendChild(el);
    return () => document.head.removeChild(el);
  },[]);
  return null;
}

// ── Icons ─────────────────────────────────────────────────────────────────────
const UserIcon   = () => <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>;
const LockIcon   = () => <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>;
const EyeIcon    = () => <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>;
const EyeOffIcon = () => <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94"/><path d="M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19"/><line x1="1" y1="1" x2="23" y2="23"/></svg>;
const ShieldIcon = () => <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/><polyline points="9 12 11 14 15 10"/></svg>;
const CapsIcon   = () => <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><polyline points="12 5 5 12 8 12 8 19 16 19 16 12 19 12 12 5"/></svg>;

// ── FormInput ─────────────────────────────────────────────────────────────────
function FormInput({ label, type, value, onChange, onKeyDown, placeholder, icon, rightElement, error, disabled, capsLock }) {
  const [focused, setFocused] = useState(false);
  return (
    <div style={{ marginBottom:"18px" }}>
      <label style={{
        display:"flex", alignItems:"center", gap:"7px",
        fontSize:"10px", fontWeight:"600", letterSpacing:"0.14em", textTransform:"uppercase",
        color: error ? "#f87171" : focused ? C.quicksand : "rgba(216,204,177,0.45)",
        marginBottom:"8px", transition:"color 0.2s", fontFamily:"'Outfit',sans-serif",
      }}>
        {label}
        {capsLock && (
          <span style={{ display:"flex", alignItems:"center", gap:"3px", color:C.quicksand, fontSize:"9px", fontWeight:"700", background:"rgba(224,197,143,0.1)", padding:"1px 7px", borderRadius:"4px", border:`1px solid rgba(224,197,143,0.24)` }}>
            <CapsIcon/> CAPS
          </span>
        )}
      </label>
      <div style={{
        display:"flex", alignItems:"center",
        background: focused ? "rgba(10,20,60,0.62)" : error ? "rgba(248,113,113,0.06)" : "rgba(10,20,60,0.44)",
        border:`1px solid ${error ? "rgba(248,113,113,0.5)" : focused ? C.quickDim : "rgba(224,197,143,0.14)"}`,
        borderRadius:"11px", transition:"all 0.25s",
        boxShadow: focused ? `0 0 0 3px ${error ? "rgba(248,113,113,0.08)" : C.quickGlow}, inset 0 1px 0 rgba(245,240,233,0.07)` : "inset 0 1px 0 rgba(245,240,233,0.04)",
        backdropFilter:"blur(18px)",
      }}>
        <div style={{ paddingLeft:"14px", color: error ? "#f87171" : focused ? C.quicksand : "rgba(60,96,112,0.7)", flexShrink:0, transition:"color 0.2s" }}>
          {icon}
        </div>
        <input
          type={type} value={value} onChange={onChange} onKeyDown={onKeyDown}
          onFocus={() => setFocused(true)} onBlur={() => setFocused(false)}
          placeholder={placeholder} disabled={disabled}
          style={{ flex:1, padding:"13px 12px", background:"transparent", border:"none", outline:"none", color:C.swanWing, fontSize:"14px", fontFamily:"'Outfit',sans-serif", fontWeight:"400" }}
        />
        {rightElement && <div style={{ paddingRight:"12px", flexShrink:0 }}>{rightElement}</div>}
      </div>
      {error && <p style={{ fontSize:"11px", color:"#f87171", marginTop:"5px", paddingLeft:"2px" }}>{error}</p>}
    </div>
  );
}

// ── Main ──────────────────────────────────────────────────────────────────────
export default function Login({ onLogin }) {
  const [form, setForm]           = useState({ username:"", password:"", rememberMe:false });
  const [showPwd, setShowPwd]     = useState(false);
  const [capsLock, setCapsLock]   = useState(false);
  const [errors, setErrors]       = useState({});
  const [globalError, setGErr]    = useState("");
  const [loading, setLoading]     = useState(false);
  const [locked, setLocked]       = useState(false);
  const [lockTimer, setLockTimer] = useState(0);
  const [attemptsLeft, setAL]     = useState(null);
  const [shake, setShake]         = useState(false);
  const [success, setSuccess]     = useState(false);
  const timerRef = useRef(null);

  useEffect(() => {
    const s = localStorage.getItem("bi_remember");
    if (s) setForm(f => ({ ...f, username:s, rememberMe:true }));
  }, []);

  useEffect(() => {
    if (locked && lockTimer > 0) {
      timerRef.current = setInterval(() => setLockTimer(t => {
        if (t <= 1) { clearInterval(timerRef.current); setLocked(false); return 0; }
        return t - 1;
      }), 1000);
    }
    return () => clearInterval(timerRef.current);
  }, [locked]);

  const validate = () => {
    const e = {};
    if (!form.username.trim()) e.username = "Ce champ est requis";
    if (!form.password)        e.password = "Ce champ est requis";
    else if (form.password.length < 4) e.password = "Mot de passe trop court";
    setErrors(e);
    return !Object.keys(e).length;
  };

  const triggerShake = () => { setShake(true); setTimeout(() => setShake(false), 600); };

  const handleSubmit = async () => {
    setGErr("");
    if (!validate()) { triggerShake(); return; }
    setLoading(true);
    try {
      const res = await axios.post("/api/auth/login", {
        username:form.username.trim(), password:form.password, rememberMe:form.rememberMe,
      });
      if (res.data.success) {
        localStorage.setItem("bi_token", res.data.token);
        localStorage.setItem("bi_user", JSON.stringify(res.data.user));
        if (form.rememberMe) localStorage.setItem("bi_remember", form.username.trim());
        else localStorage.removeItem("bi_remember");
        setSuccess(true);
        setTimeout(() => onLogin(res.data.user), 900);
      }
    } catch (err) {
      triggerShake();
      const d = err.response?.data;
      if (d?.locked) { setLocked(true); setLockTimer((d.remainingMinutes||15)*60); setGErr(d.error); }
      else if (d?.attemptsLeft !== undefined) { setAL(d.attemptsLeft); setGErr(d.error||"Identifiants incorrects"); }
      else setGErr(d?.error||"Erreur de connexion. Vérifiez que le serveur est démarré.");
    } finally { setLoading(false); }
  };

  const handleKey = e => {
    if (e.getModifierState) setCapsLock(e.getModifierState("CapsLock"));
    if (e.key === "Enter") handleSubmit();
  };
  const fmt = s => `${Math.floor(s/60)}:${String(s%60).padStart(2,"0")}`;

  return (
    <div style={{ minHeight:"100vh", display:"flex", alignItems:"center", justifyContent:"center", fontFamily:"'Outfit',sans-serif", position:"relative", padding:"20px" }}>
      <GlobalStyles/>
      <IridescentBackground/>
      <GoldenCursor/>

      {/* Very light scrim — let blue shine through */}
      <div style={{ position:"fixed", inset:0, background:"rgba(5,10,30,0.18)", zIndex:1, pointerEvents:"none" }}/>

      <div className={`login-card${shake?" shake":""}${success?" success":""}`}
        style={{ width:"100%", maxWidth:"432px", position:"relative", zIndex:10 }}>

        <div style={{
          background:"rgba(5,10,32,0.70)",
          backdropFilter:"blur(48px)", WebkitBackdropFilter:"blur(48px)",
          border:"1px solid rgba(224,197,143,0.2)",
          borderRadius:"24px", overflow:"hidden",
          boxShadow:[
            "0 40px 100px rgba(0,0,0,0.65)",
            "0 0 0 1px rgba(245,240,233,0.05)",
            "inset 0 1px 0 rgba(245,240,233,0.09)",
            "0 0 80px rgba(20,60,180,0.22)",
          ].join(","),
        }}>

          {/* Quicksand top line */}
          <div style={{ height:"2px", background:`linear-gradient(90deg, transparent, rgba(224,197,143,0.3) 20%, ${C.quicksand} 50%, rgba(224,197,143,0.3) 80%, transparent)` }}/>

          <div style={{ padding:"46px 40px 38px" }}>

            {/* Header */}
            <div style={{ textAlign:"center", marginBottom:"40px" }}>
              <div style={{
                width:"78px", height:"78px", borderRadius:"22px",
                background:`linear-gradient(145deg, ${C.royalBlue}, ${C.royalMid})`,
                border:`1px solid rgba(224,197,143,0.3)`,
                display:"flex", alignItems:"center", justifyContent:"center",
                margin:"0 auto 24px",
                animation:"quickPulse 4s ease-in-out infinite, floatUp 4.5s ease-in-out infinite",
              }}>
                <svg width="46" height="46" viewBox="0 0 46 46" fill="none">
                  <path d="M23 7 L37 38 H30.5 L23 22 L15.5 38 H9 L23 7Z" fill="none" stroke="url(#qgr3)" strokeWidth="1.8" strokeLinejoin="round"/>
                  <path d="M14 30 H32" stroke="url(#qgr3)" strokeWidth="1.4" opacity="0.5"/>
                  <circle cx="23" cy="7"  r="2.5" fill={C.quicksand} opacity="0.95"/>
                  <circle cx="9"  cy="38" r="1.8" fill={C.quicksand} opacity="0.5"/>
                  <circle cx="37" cy="38" r="1.8" fill={C.quicksand} opacity="0.5"/>
                  <defs>
                    <linearGradient id="qgr3" x1="9" y1="7" x2="37" y2="38">
                      <stop offset="0%"   stopColor={C.swanWing}/>
                      <stop offset="50%"  stopColor={C.quicksand}/>
                      <stop offset="100%" stopColor={C.shellstone}/>
                    </linearGradient>
                  </defs>
                </svg>
              </div>

              <h2 style={{ fontFamily:"'Cormorant Garamond',serif", fontWeight:"400", fontSize:"31px", color:C.swanWing, letterSpacing:"0.02em", marginBottom:"4px", lineHeight:"1.2" }}>
                Azur Hotels{" "}
                <em style={{
                  background:`linear-gradient(90deg, ${C.shellstone}, ${C.quicksand}, ${C.swanWing}, ${C.quicksand}, ${C.shellstone})`,
                  backgroundSize:"300%",
                  WebkitBackgroundClip:"text", WebkitTextFillColor:"transparent",
                  animation:"shimmer 3.5s linear infinite", fontStyle:"italic",
                }}>BI</em>
              </h2>

              <div style={{ display:"flex", alignItems:"center", gap:"8px", margin:"13px 0 10px" }}>
                <div style={{ flex:1, height:"1px", background:"linear-gradient(90deg, transparent, rgba(224,197,143,0.2))" }}/>
                <svg width="58" height="10" viewBox="0 0 58 10">
                  <circle cx="29" cy="5" r="2"   fill="rgba(224,197,143,0.6)"/>
                  <circle cx="21" cy="5" r="1.2" fill="rgba(224,197,143,0.32)"/>
                  <circle cx="37" cy="5" r="1.2" fill="rgba(224,197,143,0.32)"/>
                </svg>
                <div style={{ flex:1, height:"1px", background:"linear-gradient(90deg, rgba(224,197,143,0.2), transparent)" }}/>
              </div>

              <p style={{ color:"rgba(216,204,177,0.38)", fontSize:"10px", letterSpacing:"0.2em", fontWeight:"500" }}>
                ROYAL AZUR THALASSA · STE BEL AZUR
              </p>
            </div>

            {locked && (
              <div style={{ background:"rgba(239,68,68,0.08)", border:"1px solid rgba(239,68,68,0.22)", borderRadius:"10px", padding:"12px 14px", marginBottom:"20px", display:"flex", alignItems:"center", gap:"10px" }}>
                <span>🔒</span>
                <div>
                  <p style={{ color:"#f87171", fontSize:"12.5px", fontWeight:"600", marginBottom:"2px" }}>Accès temporairement bloqué</p>
                  <p style={{ color:"#94a3b8", fontSize:"11.5px" }}>Déblocage dans <span style={{ color:C.quicksand, fontWeight:"700", fontVariantNumeric:"tabular-nums" }}>{fmt(lockTimer)}</span></p>
                </div>
              </div>
            )}

            {globalError && !locked && (
              <div style={{ background:"rgba(239,68,68,0.07)", border:"1px solid rgba(239,68,68,0.2)", borderRadius:"10px", padding:"11px 14px", marginBottom:"20px", display:"flex", justifyContent:"space-between", alignItems:"center" }}>
                <p style={{ color:"#f87171", fontSize:"12.5px" }}>{globalError}</p>
                {attemptsLeft !== null && attemptsLeft > 0 && (
                  <span style={{ background:"rgba(239,68,68,0.15)", color:"#f87171", fontSize:"10px", fontWeight:"700", padding:"2px 8px", borderRadius:"999px", whiteSpace:"nowrap", marginLeft:"8px" }}>
                    {attemptsLeft} essai{attemptsLeft>1?"s":""}
                  </span>
                )}
              </div>
            )}

            <FormInput label="Identifiant" type="text" value={form.username}
              onChange={e => { setForm({...form,username:e.target.value}); setErrors({}); setGErr(""); }}
              onKeyDown={handleKey} placeholder="Votre identifiant"
              icon={<UserIcon/>} error={errors.username} disabled={loading||locked}
            />
            <FormInput label="Mot de passe" type={showPwd?"text":"password"} value={form.password}
              onChange={e => { setForm({...form,password:e.target.value}); setErrors({}); setGErr(""); }}
              onKeyDown={handleKey} placeholder="••••••••"
              icon={<LockIcon/>} error={errors.password} disabled={loading||locked} capsLock={capsLock}
              rightElement={
                <button onClick={() => setShowPwd(!showPwd)}
                  style={{ background:"none",border:"none",cursor:"none",color:"rgba(60,96,112,0.6)",padding:"4px",borderRadius:"6px",display:"flex",alignItems:"center",transition:"color 0.2s" }}
                  onMouseEnter={e => e.currentTarget.style.color = C.quicksand}
                  onMouseLeave={e => e.currentTarget.style.color = "rgba(60,96,112,0.6)"}
                >
                  {showPwd ? <EyeOffIcon/> : <EyeIcon/>}
                </button>
              }
            />

            <div style={{ display:"flex", alignItems:"center", gap:"10px", marginBottom:"26px" }}>
              <div onClick={() => !locked && setForm(f=>({...f,rememberMe:!f.rememberMe}))} style={{
                width:"17px", height:"17px", borderRadius:"5px", flexShrink:0,
                border:`1.5px solid ${form.rememberMe ? C.quicksand : "rgba(224,197,143,0.17)"}`,
                background: form.rememberMe ? "rgba(224,197,143,0.12)" : "transparent",
                cursor:"none", display:"flex", alignItems:"center", justifyContent:"center", transition:"all 0.2s",
              }}>
                {form.rememberMe && <svg width="10" height="10" viewBox="0 0 12 12" fill="none" stroke={C.quicksand} strokeWidth="2.5" strokeLinecap="round"><polyline points="1.5 6 4.5 9 10.5 3"/></svg>}
              </div>
              <span onClick={() => !locked && setForm(f=>({...f,rememberMe:!f.rememberMe}))}
                style={{ fontSize:"12.5px", color:"rgba(216,204,177,0.3)", cursor:"none" }}>
                Se souvenir de moi <span style={{ color:"rgba(200,185,160,0.2)" }}>— 7 jours</span>
              </span>
            </div>

            <button className="connect-btn" onClick={handleSubmit} disabled={loading||locked||success} style={{
              width:"100%", padding:"15px",
              background: success ? "linear-gradient(135deg,#166534,#22c55e)"
                : locked  ? "rgba(255,255,255,0.05)"
                : loading ? "rgba(224,197,143,0.38)"
                : `linear-gradient(135deg, ${C.shellstone} 0%, ${C.quicksand} 45%, ${C.swanWing} 100%)`,
              border: locked  ? "1px solid rgba(255,255,255,0.07)"
                : success ? "1px solid rgba(34,197,94,0.4)"
                : `1px solid rgba(224,197,143,0.42)`,
              borderRadius:"12px",
              color: locked ? "#475569" : success ? "#fff" : C.royalBlue,
              fontSize:"12.5px", fontWeight:"700", cursor:"none",
              letterSpacing:"0.1em", textTransform:"uppercase", transition:"all 0.3s",
              boxShadow: success ? "0 4px 22px rgba(34,197,94,0.4)"
                : locked ? "none"
                : `0 6px 30px rgba(224,197,143,0.38), inset 0 1px 0 rgba(255,255,255,0.35)`,
              display:"flex", alignItems:"center", justifyContent:"center", gap:"8px",
              fontFamily:"'Outfit',sans-serif",
            }}>
              {success ? (
                <><svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="#fff" strokeWidth="2.5" strokeLinecap="round"><polyline className="check-path" points="4 12 9 17 20 6"/></svg> Connexion réussie</>
              ) : loading ? (
                <><div style={{ width:"15px",height:"15px",border:`2px solid rgba(17,34,80,0.3)`,borderTopColor:C.royalBlue,borderRadius:"50%",animation:"spin .75s linear infinite" }}/> Authentification…</>
              ) : locked ? `🔒 Bloqué — ${fmt(lockTimer)}`
                : <><ShieldIcon/> Se connecter</>}
            </button>
          </div>

          <div style={{ borderTop:"1px solid rgba(224,197,143,0.08)", padding:"14px 40px", display:"flex", justifyContent:"center", gap:"24px", background:"rgba(0,0,0,0.28)" }}>
            {["JWT Token","Rate Limiting","AES-256"].map(t => (
              <div key={t} style={{ display:"flex", alignItems:"center", gap:"5px" }}>
                <div style={{ width:"5px",height:"5px",borderRadius:"50%",background:C.quicksand,opacity:0.65,boxShadow:`0 0 6px rgba(224,197,143,0.55)` }}/>
                <span style={{ color:"rgba(216,204,177,0.28)", fontSize:"9px", letterSpacing:"0.08em", fontWeight:"500" }}>{t}</span>
              </div>
            ))}
          </div>
        </div>

        <p style={{ textAlign:"center", color:"rgba(60,96,112,0.32)", fontSize:"9.5px", marginTop:"18px", letterSpacing:"0.08em" }}>
          STE BEL AZUR © 2025 — Usage interne uniquement
        </p>
      </div>
    </div>
  );
}