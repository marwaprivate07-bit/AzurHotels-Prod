import { useState, useEffect } from "react";
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid,
  Tooltip, Legend, ResponsiveContainer
} from "recharts";
import { getChargesCompar } from "../services/api";
import KpiCard from "../components/KpiCard";
import { useDashboard } from "../components/DashboardContext";
import { IconWallet, IconArchive, IconBarChart, IconTag } from "../components/KpiIcons";
import ChartCard from "../components/ChartCard";
import Section from "../components/Section";

const fmtTND = (v) => `${(v/1000).toFixed(1)} K TND`;

const tooltipStyleCharges = {
  background: "rgba(15,23,42,0.96)",
  borderRadius: 10,
  border: "1px solid rgba(248,113,113,0.7)",
  padding: "8px 10px",
  color: "#fee2e2",
  boxShadow: "0 18px 40px rgba(127,29,29,0.7)",
};

const tooltipLabelCharges = {
  marginBottom: 4,
  fontSize: 11,
  fontWeight: 600,
  color: "#fecaca",
  textTransform: "uppercase",
  letterSpacing: "0.06em",
};

export default function Charges() {
  const { hotelId, annee } = useDashboard();
  const [charges, setCharges] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    setLoading(true);
    setError(null);
    getChargesCompar(annee, hotelId)
      .then(res => setCharges(res.data.data))
      .catch(e => {
        console.error("Erreur API Charges:", e);
        setError("Erreur de chargement des données : " + (e?.message || "backend inaccessible"));
      })
      .finally(() => setLoading(false));
  }, [annee, hotelId]);

  const totalN  = charges.reduce((s,r) => s + parseFloat(r.montant_n||0), 0);
  const totalN1 = charges.reduce((s,r) => s + parseFloat(r.montant_n1||0), 0);
  const delta = totalN1 > 0 ? ((totalN - totalN1) / totalN1 * 100).toFixed(1) : 0;
  const posteMax = charges.length > 0
    ? charges.reduce((m,r) => parseFloat(r.montant_n) > parseFloat(m.montant_n) ? r : m, charges[0])
    : {};

  if (loading) return (
    <div className="flex items-center justify-center h-64">
      <div className="animate-spin rounded-full h-10 w-10 border-4 border-[#1E3A5F] border-t-transparent"/>
    </div>
  );

  if (error) return (
    <div className="flex items-center justify-center h-64">
      <div className="text-center text-red-500">
        <p className="text-lg font-semibold mb-1">Erreur de chargement</p>
        <p className="text-sm text-gray-500">{error}</p>
      </div>
    </div>
  );

  return (
    <div className="p-6">
      <Section
        title="Vue d’ensemble des charges opérationnelles"
        subtitle="Comparaison des charges annuelles et identification du poste principal."
      />

      {/* KPI Cards */}
      <div className="grid grid-cols-4 gap-4 mb-6">
        <KpiCard icon={<IconWallet />} title={`Total Charges ${annee}`} value={fmtTND(totalN)} color="#F43060" subtitle="toutes catégories" />
        <KpiCard icon={<IconArchive />} title={`Total Charges ${annee-1}`} value={fmtTND(totalN1)} color="#F59E0B" subtitle="année précédente" />
        <KpiCard icon={<IconBarChart />} title="Évolution" value={`${parseFloat(delta) >= 0 ? "+" : ""}${delta}%`} color={parseFloat(delta) >= 0 ? "#F43060" : "#10B981"} subtitle="vs année N-1" />
        <KpiCard icon={<IconTag />} title="Poste Principal" value={posteMax.poste || "-"} color="#8B5CF6" subtitle={posteMax.montant_n ? fmtTND(posteMax.montant_n) : ""} />
      </div>

      {/* Graphique comparaison */}
      <ChartCard
        title={`Comparaison ${annee} vs ${annee - 1} par poste`}
        subtitle="Analyse des évolutions de charges par nature de poste."
        className="mb-4"
      >
        <ResponsiveContainer width="100%" height={280}>
          <BarChart data={charges} barSize={20}>
            <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
            <XAxis dataKey="poste" tick={{fontSize:10}} />
            <YAxis tickFormatter={v=>`${(v/1000000).toFixed(1)}M`} tick={{fontSize:10}} />
            <Tooltip
              formatter={v=>[fmtTND(v)]}
              contentStyle={tooltipStyleCharges}
              labelStyle={tooltipLabelCharges}
              cursor={{ fill: "rgba(248,113,113,0.06)" }}
            />
            <Legend wrapperStyle={{fontSize:11}} />
            <Bar
              dataKey="montant_n"
              name={String(annee)}
              fill="#f97373"
              radius={[6,6,0,0]}
            />
            <Bar
              dataKey="montant_n1"
              name={String(annee-1)}
              fill="#fed7d7"
              radius={[6,6,0,0]}
            />
          </BarChart>
        </ResponsiveContainer>
      </ChartCard>

      {/* Tableau détail */}
      <ChartCard
        title="Détail des charges par poste"
        subtitle="Lecture détaillée des montants et taux d’évolution par poste."
        accent="#F59E0B"
      >
        <table className="w-full text-sm">
          <thead>
            <tr className="bg-[#1E3A5F] text-white">
              <th className="p-3 text-left rounded-tl-lg">Poste</th>
              <th className="p-3 text-right">{annee} (TND)</th>
              <th className="p-3 text-right">{annee-1} (TND)</th>
              <th className="p-3 text-right rounded-tr-lg">Évolution</th>
            </tr>
          </thead>
          <tbody>
            {charges.map((row, i) => {
              const d = row.montant_n1 > 0
                ? ((row.montant_n - row.montant_n1) / row.montant_n1 * 100).toFixed(1)
                : null;
              return (
                <tr key={i} className={i%2===0?"bg-white":"bg-gray-50"}>
                  <td className="p-3 font-medium text-gray-700 capitalize">{row.poste}</td>
                  <td className="p-3 text-right font-mono">{parseFloat(row.montant_n).toLocaleString("fr-TN")}</td>
                  <td className="p-3 text-right font-mono text-gray-400">{parseFloat(row.montant_n1).toLocaleString("fr-TN")}</td>
                  <td className={`p-3 text-right font-semibold ${parseFloat(d)>0?"text-red-500":"text-green-600"}`}>
                    {d ? `${parseFloat(d)>0?"+":""}${d}%` : "-"}
                  </td>
                </tr>
              );
            })}
            <tr className="bg-[#1E3A5F] text-white font-bold">
              <td className="p-3 rounded-bl-lg">TOTAL</td>
              <td className="p-3 text-right font-mono">{totalN.toLocaleString("fr-TN")}</td>
              <td className="p-3 text-right font-mono">{totalN1.toLocaleString("fr-TN")}</td>
              <td className="p-3 text-right rounded-br-lg">{parseFloat(delta) >= 0 ? "+" : ""}{delta}%</td>
            </tr>
          </tbody>
        </table>
      </ChartCard>
    </div>
  );
}
