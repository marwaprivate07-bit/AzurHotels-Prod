import { useState, useEffect } from "react";
import {
  BarChart, Bar, LineChart, Line, AreaChart, Area,
  XAxis, YAxis, CartesianGrid, Tooltip, Legend,
  ResponsiveContainer, ComposedChart, ReferenceLine, Cell
} from "recharts";
import {
  getStatsMensuel, getStatsKpi, getStatsCompar,
  getArrivees, getNationalites, getAgences
} from "../services/api";
import KpiCard from "../components/KpiCard";
import { useDashboard } from "../components/DashboardContext";
import { IconBed, IconUsers, IconOccupancy, IconBuilding, IconCoins, IconLayers, IconUser, IconStar, IconUserMinus, IconHeart } from "../components/KpiIcons";
import ChartCard from "../components/ChartCard";
import Section from "../components/Section";

// ── Helpers ──────────────────────────────────────────────────────────────────
const fmt  = (v, dec = 0) => parseFloat(v || 0).toLocaleString("fr-TN", { minimumFractionDigits: dec, maximumFractionDigits: dec });
const fmtK = (v) => `${(parseFloat(v || 0) / 1000).toFixed(1)} K`;

const tooltipStyleStats = {
  background: "rgba(15,23,42,0.96)",
  borderRadius: 10,
  border: "1px solid rgba(148,163,184,0.6)",
  padding: "8px 10px",
  color: "#e5e7eb",
  boxShadow: "0 18px 40px rgba(15,23,42,0.55)",
};

const tooltipLabelStats = {
  marginBottom: 4,
  fontSize: 11,
  fontWeight: 600,
  color: "#9ca3af",
  textTransform: "uppercase",
  letterSpacing: "0.06em",
};

// Small metric badge inside tables
function Badge({ value, positive }) {
  const isPos = positive ?? parseFloat(value) >= 0;
  return (
    <span className={`text-xs font-semibold px-2 py-0.5 rounded-full ${isPos ? "bg-green-50 text-green-600" : "bg-red-50 text-red-500"}`}>
      {parseFloat(value) > 0 ? "+" : ""}{value}%
    </span>
  );
}

export default function Stats() {
  const { hotelId, annee } = useDashboard();
  const [mensuel,      setMensuel]      = useState([]);
  const [kpi,          setKpi]          = useState(null);
  const [compar,       setCompar]       = useState([]);
  const [arrivees,     setArrivees]     = useState([]);
  const [nationalites, setNationalites] = useState([]);
  const [agences,      setAgences]      = useState([]);
  const [loading,      setLoading]      = useState(true);
  const [error,        setError]        = useState(null);

  useEffect(() => {
    setLoading(true);
    setError(null);
    Promise.all([
      getStatsMensuel(annee, hotelId),
      getStatsKpi(annee, hotelId),
      getStatsCompar(annee, hotelId),
      getArrivees(annee, hotelId),
      getNationalites(annee, hotelId),
      getAgences(annee, hotelId),
    ])
      .then(([m, k, c, a, n, ag]) => {
        setMensuel(m.data.data);
        setKpi(k.data.data);
        setCompar(c.data.data);
        setArrivees(a.data.data);
        setNationalites(n.data.data);
        setAgences(ag.data.data);
      })
      .catch((e) => {
        setError("Erreur de chargement des données : " + (e?.message || "backend inaccessible"));
      })
      .finally(() => setLoading(false));
  }, [annee, hotelId]);

  if (loading) return (
    <div className="flex items-center justify-center h-64">
      <div className="animate-spin rounded-full h-10 w-10 border-4 border-[#1E3A5F] border-t-transparent" />
    </div>
  );

  if (error) return (
    <div className="flex items-center justify-center h-64">
      <div className="text-center text-red-500">
        <p className="text-lg font-semibold mb-1">Erreur de chargement</p>
        <p className="text-sm text-gray-500">{error}</p>
      </div>
    </div>
  );

  return (
    <div className="p-6 max-w-screen-xl">

      <Section
        title="Vue d’ensemble des indicateurs d’activité"
        subtitle="Synthèse annuelle des principaux indicateurs opérationnels de l’hôtel."
      />

      {/* 1. KPI ANNUELS */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4">
        <KpiCard icon={<IconBed />}      title="Total Nuitées"      value={fmt(kpi?.total_nuitees)}                                color="#1E3A5F" subtitle={`Année ${annee}`} />
        <KpiCard icon={<IconUsers />}    title="Total Arrivées"     value={fmt(kpi?.total_arrivees)}                               color="#2E86AB" subtitle="adultes + enfants + bébés" />
        <KpiCard icon={<IconOccupancy />} title="TO Lit Moyen"      value={`${fmt(kpi?.avg_to_lit_pct, 1)}%`}                     color="#1A6B3A" subtitle="taux occupation lit"       gauge={parseFloat(kpi?.avg_to_lit_pct||0)} />
        <KpiCard icon={<IconBuilding />} title="TO Chambre Moyen"   value={`${fmt(kpi?.avg_taux_occupation_chambres, 1)}%`}        color="#457B9D" subtitle="taux occupation chambre"   gauge={parseFloat(kpi?.avg_taux_occupation_chambres||0)} />
      </div>
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4">
        <KpiCard icon={<IconCoins />}    title="ADR Moyen"          value={`${fmt(kpi?.avg_adr, 2)} TND`}                         color="#E67E22" subtitle="revenu moyen / pax" />
        <KpiCard icon={<IconLayers />}   title="RevPAR Moyen"       value={`${fmt(kpi?.avg_revpar, 2)} TND`}                      color="#8E44AD" subtitle="revenue per available room" />
        <KpiCard icon={<IconUsers />}    title="Indice Fréq. Moyen" value={fmt(kpi?.avg_indice_freq, 4)}                          color="#C0392B" subtitle="fréquentation moyenne" />
        <KpiCard icon={<IconStar />}     title="Booking Score Moy." value={`${fmt(kpi?.avg_booking_score, 2)} / 10`}              color="#16A085" subtitle={`${kpi?.nb_chambres || "-"} chambres`} gauge={parseFloat(kpi?.avg_booking_score||0)*10} />
      </div>

      {/* Arrivées détail */}
      <div className="grid grid-cols-3 gap-4 mb-2">
        <KpiCard icon={<IconUser />}     title="Arrivées Adultes"   value={fmt(kpi?.total_arr_adulte)}  color="#1E3A5F" subtitle="pax adultes" />
        <KpiCard icon={<IconUserMinus />} title="Arrivées Enfants"  value={fmt(kpi?.total_arr_enfant)}  color="#2E86AB" subtitle="pax enfants" />
        <KpiCard icon={<IconHeart />}    title="Arrivées Bébés"     value={fmt(kpi?.total_arr_bebe)}    color="#A8DADC" subtitle="pax bébés" />
      </div>

      <Section
        title="Indicateurs mensuels de performance"
        subtitle="Dynamique mensuelle des nuitées, taux d’occupation et indicateurs de rentabilité."
      />

      {/* 2. INDICATEURS MENSUELS — redesigned */}

      {/* Chart 1 — Nuitées colored by season + TO overlay */}
      <div className="mb-4">
        <ChartCard title="Nuitées mensuelles & Taux d'Occupation" subtitle="Barres colorées par saison · Ligne = TO Lit %">
          {(() => {
            const MONTH_SEASON = {1:"Basse",2:"Basse",3:"Basse",4:"Moyenne",5:"Moyenne",6:"Haute",7:"Haute",8:"Haute",9:"Haute",10:"Moyenne",11:"Basse",12:"Basse"};
            const SEA_COLOR    = {"Haute":"#1E3A5F","Moyenne":"#2E86AB","Basse":"#A8DADC"};
            const SEA_LABEL    = {"Haute":"Haute saison ☀️","Moyenne":"Moyenne saison 🌤️","Basse":"Basse saison ❄️"};
            const maxNuit = Math.max(...mensuel.map(r => parseFloat(r.nuitees||0)));
            const enriched = mensuel.map((r,i) => ({ ...r, isPeak: parseFloat(r.nuitees) === maxNuit }));
            return (
              <div>
                <div style={{ display:"flex", gap:16, marginBottom:8, paddingLeft:4 }}>
                  {Object.entries(SEA_LABEL).map(([k,v]) => (
                    <div key={k} style={{ display:"flex", alignItems:"center", gap:5 }}>
                      <span style={{ width:10, height:10, borderRadius:3, background:SEA_COLOR[k], display:"inline-block" }}/>
                      <span style={{ fontSize:10, color:"#4a6080", fontWeight:600 }}>{v}</span>
                    </div>
                  ))}
                  <div style={{ display:"flex", alignItems:"center", gap:5, marginLeft:"auto" }}>
                    <span style={{ width:20, height:3, background:"#c9a84c", display:"inline-block", borderRadius:2 }}/>
                    <span style={{ fontSize:10, color:"#4a6080", fontWeight:600 }}>TO Lit %</span>
                  </div>
                </div>
                <ResponsiveContainer width="100%" height={260}>
                  <ComposedChart data={enriched} margin={{ top:16, right:20, left:0, bottom:0 }} barSize={28}>
                    <defs>
                      <linearGradient id="gradTO" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="0%" stopColor="#c9a84c" stopOpacity={0.12}/>
                        <stop offset="100%" stopColor="#c9a84c" stopOpacity={0}/>
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" stroke="rgba(180,210,235,0.4)" vertical={false}/>
                    <XAxis dataKey="mois_nom" tick={{ fontSize:10, fill:"#7a95b0" }} axisLine={false} tickLine={false}/>
                    <YAxis yAxisId="bar" tick={{ fontSize:10, fill:"#7a95b0" }} axisLine={false} tickLine={false}/>
                    <YAxis yAxisId="to" orientation="right" tickFormatter={v=>`${v}%`} tick={{ fontSize:10, fill:"#c9a84c" }} axisLine={false} tickLine={false} domain={[0,100]}/>
                    <Tooltip contentStyle={tooltipStyleStats} labelStyle={tooltipLabelStats}
                      formatter={(v,name) => name==="TO Lit %" ? [`${parseFloat(v).toFixed(1)}%`, name] : [v.toLocaleString(), name]}/>
                    <Bar yAxisId="bar" dataKey="nuitees" name="Nuitées" radius={[5,5,0,0]}
                      label={{ position:"top", formatter:(v,entry,idx)=> enriched[idx]?.isPeak?"🏆":"", fontSize:14 }}>
                      {enriched.map((_,i) => <Cell key={i} fill={SEA_COLOR[MONTH_SEASON[i+1]||"Basse"]} opacity={enriched[i].isPeak?1:0.82}/>)}
                    </Bar>
                    <Area yAxisId="to" type="monotone" dataKey="to_lit_pct" name="TO Lit %"
                      stroke="#c9a84c" strokeWidth={2.5} fill="url(#gradTO)"
                      dot={false} activeDot={{ r:5, fill:"#c9a84c", stroke:"#fff", strokeWidth:2 }}/>
                  </ComposedChart>
                </ResponsiveContainer>
              </div>
            );
          })()}
        </ChartCard>
      </div>

      {/* Charts 2 & 3 — ADR/RevPAR + TO Chambre vs Lit */}
      <div className="grid grid-cols-2 gap-4 mb-4">
        <ChartCard title="ADR & RevPAR mensuel (TND)" subtitle="Barres = ADR · Ligne = RevPAR">
          <div>
            <ResponsiveContainer width="100%" height={240}>
              <ComposedChart data={mensuel} margin={{ top:8, right:20, left:0, bottom:0 }} barSize={24}>
                <defs>
                  <linearGradient id="gradADR" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#E67E22" stopOpacity={0.9}/>
                    <stop offset="100%" stopColor="#E67E22" stopOpacity={0.5}/>
                  </linearGradient>
                  <linearGradient id="gradRevpar" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#8E44AD" stopOpacity={0.15}/>
                    <stop offset="100%" stopColor="#8E44AD" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(180,210,235,0.4)" vertical={false}/>
                <XAxis dataKey="mois_nom" tick={{ fontSize:10, fill:"#7a95b0" }} axisLine={false} tickLine={false}/>
                <YAxis yAxisId="adr" tick={{ fontSize:10, fill:"#E67E22" }} axisLine={false} tickLine={false}/>
                <YAxis yAxisId="rev" orientation="right" tick={{ fontSize:10, fill:"#8E44AD" }} axisLine={false} tickLine={false}/>
                <Tooltip contentStyle={tooltipStyleStats} labelStyle={tooltipLabelStats} formatter={v=>[`${parseFloat(v).toFixed(2)} TND`]}/>
                <Legend wrapperStyle={{ fontSize:11, paddingTop:6 }}/>
                <Bar yAxisId="adr" dataKey="adr" name="ADR" fill="url(#gradADR)" radius={[4,4,0,0]}/>
                <Area yAxisId="rev" type="monotone" dataKey="revpar" name="RevPAR"
                  stroke="#8E44AD" strokeWidth={2.5} fill="url(#gradRevpar)"
                  dot={{ r:3, fill:"#8E44AD", stroke:"#fff", strokeWidth:1 }}
                  activeDot={{ r:5, stroke:"#fff", strokeWidth:2 }}/>
              </ComposedChart>
            </ResponsiveContainer>
          </div>
        </ChartCard>

        <ChartCard title="TO Lit vs TO Chambre (%)" subtitle="Évolution mensuelle des taux d'occupation">
          <div>
            <ResponsiveContainer width="100%" height={240}>
              <ComposedChart data={mensuel} margin={{ top:8, right:20, left:0, bottom:0 }}>
                <defs>
                  <linearGradient id="gradLit" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#1A6B3A" stopOpacity={0.15}/>
                    <stop offset="100%" stopColor="#1A6B3A" stopOpacity={0}/>
                  </linearGradient>
                  <linearGradient id="gradChamb" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#457B9D" stopOpacity={0.12}/>
                    <stop offset="100%" stopColor="#457B9D" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(180,210,235,0.4)" vertical={false}/>
                <XAxis dataKey="mois_nom" tick={{ fontSize:10, fill:"#7a95b0" }} axisLine={false} tickLine={false}/>
                <YAxis tickFormatter={v=>`${v}%`} tick={{ fontSize:10, fill:"#7a95b0" }} axisLine={false} tickLine={false} domain={[0,100]}/>
                <Tooltip contentStyle={tooltipStyleStats} labelStyle={tooltipLabelStats} formatter={v=>[`${parseFloat(v).toFixed(1)}%`]}/>
                <Legend wrapperStyle={{ fontSize:11, paddingTop:6 }}/>
                <Area type="monotone" dataKey="to_lit_pct" name="TO Lit %"
                  stroke="#1A6B3A" strokeWidth={2.5} fill="url(#gradLit)"
                  dot={{ r:3, fill:"#1A6B3A", stroke:"#fff", strokeWidth:1 }}
                  activeDot={{ r:5, stroke:"#fff", strokeWidth:2 }}/>
                <Area type="monotone" dataKey="taux_occupation_chambres" name="TO Chambre %"
                  stroke="#457B9D" strokeWidth={2} strokeDasharray="5 3" fill="url(#gradChamb)"
                  dot={{ r:2, fill:"#457B9D" }} activeDot={{ r:4, stroke:"#fff", strokeWidth:2 }}/>
              </ComposedChart>
            </ResponsiveContainer>
          </div>
        </ChartCard>
      </div>

      {/* Chart 4 — Indice freq + Booking score side by side */}
      <div className="grid grid-cols-2 gap-4 mb-4">
        <ChartCard title="Indice de Fréquentation mensuel" subtitle="Nombre moyen de personnes par chambre">
          <ResponsiveContainer width="100%" height={220}>
            <AreaChart data={mensuel} margin={{ top:8, right:16, left:0, bottom:0 }}>
              <defs>
                <linearGradient id="gradFreq2" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%"  stopColor="#16A085" stopOpacity={0.25}/>
                  <stop offset="95%" stopColor="#16A085" stopOpacity={0}/>
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(180,210,235,0.4)" vertical={false}/>
              <XAxis dataKey="mois_nom" tick={{ fontSize:10, fill:"#7a95b0" }} axisLine={false} tickLine={false}/>
              <YAxis tick={{ fontSize:10, fill:"#7a95b0" }} axisLine={false} tickLine={false} domain={["auto","auto"]}/>
              <Tooltip contentStyle={tooltipStyleStats} labelStyle={tooltipLabelStats} formatter={v=>[parseFloat(v).toFixed(2), "Indice Fréq."]}/>
              <Area type="monotone" dataKey="indice_freq" stroke="#16A085" strokeWidth={2.5} fill="url(#gradFreq2)"
                dot={{ r:3, fill:"#16A085", stroke:"#fff", strokeWidth:1 }} activeDot={{ r:5, stroke:"#fff", strokeWidth:2 }} name="Indice Fréq."/>
            </AreaChart>
          </ResponsiveContainer>
        </ChartCard>

        <ChartCard title="Booking Score mensuel (/ 10)" subtitle="Satisfaction client — source Booking.com">
          <ResponsiveContainer width="100%" height={220}>
            <ComposedChart data={mensuel} margin={{ top:8, right:16, left:0, bottom:0 }}>
              <defs>
                <linearGradient id="gradScore" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#16A085" stopOpacity={0.18}/>
                  <stop offset="100%" stopColor="#16A085" stopOpacity={0}/>
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(180,210,235,0.4)" vertical={false}/>
              <XAxis dataKey="mois_nom" tick={{ fontSize:10, fill:"#7a95b0" }} axisLine={false} tickLine={false}/>
              <YAxis tick={{ fontSize:10, fill:"#7a95b0" }} axisLine={false} tickLine={false} domain={[0,10]}/>
              <Tooltip contentStyle={tooltipStyleStats} labelStyle={tooltipLabelStats} formatter={v=>[`${parseFloat(v).toFixed(2)} / 10`, "Score"]}/>
              <ReferenceLine y={8} stroke="#1A6B3A" strokeDasharray="4 2" strokeWidth={1.5} label={{ value:"Objectif 8", fill:"#1A6B3A", fontSize:9, position:"right" }}/>
              <Area type="monotone" dataKey="booking_score" stroke="#16A085" strokeWidth={2.5} fill="url(#gradScore)"
                dot={(props) => {
                  const { cx, cy, payload } = props;
                  const score = parseFloat(payload.booking_score||0);
                  const color = score >= 8 ? "#1A6B3A" : score >= 6 ? "#E67E22" : "#C0392B";
                  return <circle key={cx} cx={cx} cy={cy} r={4} fill={color} stroke="#fff" strokeWidth={1.5}/>;
                }}
                activeDot={{ r:6, stroke:"#fff", strokeWidth:2 }} name="Score"/>
            </ComposedChart>
          </ResponsiveContainer>
        </ChartCard>
      </div>

      {/* Tableau mensuel complet */}
      <ChartCard
        title="Tableau mensuel complet"
        subtitle="Lecture détaillée des indicateurs opérationnels pour chaque mois."
        className="mb-4"
      >
        <div className="overflow-x-auto">
          <table className="w-full text-xs">
            <thead>
              <tr className="bg-[#1E3A5F] text-white">
                <th className="p-2 text-left rounded-tl-lg">Mois</th>
                <th className="p-2 text-right">Nuitées</th>
                <th className="p-2 text-right">Ch. Occ.</th>
                <th className="p-2 text-right">TO Lit %</th>
                <th className="p-2 text-right">TO Ch. %</th>
                <th className="p-2 text-right">ADR</th>
                <th className="p-2 text-right">RevPAR</th>
                <th className="p-2 text-right">Indice Fréq.</th>
                <th className="p-2 text-right">Arrivées</th>
                <th className="p-2 text-right rounded-tr-lg">Score</th>
              </tr>
            </thead>
            <tbody>
              {mensuel.map((r, i) => (
                <tr key={i} className={i % 2 === 0 ? "bg-white" : "bg-gray-50"}>
                  <td className="p-2 font-semibold text-gray-700">{r.mois_nom}</td>
                  <td className="p-2 text-right font-mono">{fmt(r.nuitees)}</td>
                  <td className="p-2 text-right font-mono">{fmt(r.ch_occupees)}</td>
                  <td className="p-2 text-right font-mono">{fmt(r.to_lit_pct, 1)}%</td>
                  <td className="p-2 text-right font-mono">{fmt(r.taux_occupation_chambres, 1)}%</td>
                  <td className="p-2 text-right font-mono">{fmt(r.adr, 2)}</td>
                  <td className="p-2 text-right font-mono text-purple-600">{fmt(r.revpar, 2)}</td>
                  <td className="p-2 text-right font-mono">{parseFloat(r.indice_freq || 0).toFixed(4)}</td>
                  <td className="p-2 text-right font-mono">{fmt(r.arr_total)}</td>
                  <td className="p-2 text-right font-mono text-green-600">{fmt(r.booking_score, 2)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </ChartCard>

      <Section
        title={`Comparaison ${annee} vs ${annee - 1}`}
        subtitle="Comparaison annuelle des volumes de nuitées, taux d’occupation et ADR."
      />

      {/* 3. COMPARAISON N vs N-1 */}
      <div className="grid grid-cols-2 gap-4 mb-4">
        <ChartCard title={`Nuitées ${annee} vs ${annee - 1}`}>
          <ResponsiveContainer width="100%" height={220}>
            <BarChart data={compar} barSize={12}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
              <XAxis dataKey="mois_nom" tick={{ fontSize: 10 }} />
              <YAxis tick={{ fontSize: 10 }} />
              <Tooltip />
              <Legend wrapperStyle={{ fontSize: 11 }} />
              <Bar dataKey="nuitees_n"  name={String(annee)}      fill="#1E3A5F" radius={[3,3,0,0]} />
              <Bar dataKey="nuitees_n1" name={String(annee - 1)}  fill="#A8DADC" radius={[3,3,0,0]} />
            </BarChart>
          </ResponsiveContainer>
        </ChartCard>

        <ChartCard title={`TO Lit % — ${annee} vs ${annee - 1}`}>
          <ResponsiveContainer width="100%" height={220}>
            <LineChart data={compar}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
              <XAxis dataKey="mois_nom" tick={{ fontSize: 10 }} />
              <YAxis tickFormatter={v => `${v}%`} tick={{ fontSize: 10 }} />
              <Tooltip formatter={v => [`${parseFloat(v).toFixed(1)}%`]} />
              <Legend wrapperStyle={{ fontSize: 11 }} />
              <Line type="monotone" dataKey="to_lit_n"  name={String(annee)}     stroke="#1E3A5F" strokeWidth={2.5} dot={{ r: 3 }} />
              <Line type="monotone" dataKey="to_lit_n1" name={String(annee - 1)} stroke="#A8DADC" strokeWidth={2} strokeDasharray="4 2" dot={{ r: 2 }} />
            </LineChart>
          </ResponsiveContainer>
        </ChartCard>
      </div>

      <div className="grid grid-cols-2 gap-4 mb-4">
        <ChartCard title={`ADR — ${annee} vs ${annee - 1}`}>
          <ResponsiveContainer width="100%" height={220}>
            <BarChart data={compar} barSize={12}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
              <XAxis dataKey="mois_nom" tick={{ fontSize: 10 }} />
              <YAxis tick={{ fontSize: 10 }} />
              <Tooltip formatter={v => [`${parseFloat(v).toFixed(2)} TND`]} />
              <Legend wrapperStyle={{ fontSize: 11 }} />
              <Bar dataKey="adr_n"  name={String(annee)}     fill="#E67E22" radius={[3,3,0,0]} />
              <Bar dataKey="adr_n1" name={String(annee - 1)} fill="#F8C49A" radius={[3,3,0,0]} />
            </BarChart>
          </ResponsiveContainer>
        </ChartCard>

        <ChartCard title={`Arrivées totales — ${annee} vs ${annee - 1}`}>
          <ResponsiveContainer width="100%" height={220}>
            <BarChart data={compar} barSize={12}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
              <XAxis dataKey="mois_nom" tick={{ fontSize: 10 }} />
              <YAxis tick={{ fontSize: 10 }} />
              <Tooltip />
              <Legend wrapperStyle={{ fontSize: 11 }} />
              <Bar dataKey="arr_total_n"  name={String(annee)}     fill="#2E86AB" radius={[3,3,0,0]} />
              <Bar dataKey="arr_total_n1" name={String(annee - 1)} fill="#A8DADC" radius={[3,3,0,0]} />
            </BarChart>
          </ResponsiveContainer>
        </ChartCard>
      </div>

      {/* Tableau comparaison */}
      <ChartCard
        title="Tableau de comparaison N vs N-1"
        subtitle="Suivi des écarts en volume et en pourcentage entre N et N-1."
        className="mb-4"
      >
        <div className="overflow-x-auto">
          <table className="w-full text-xs">
            <thead>
              <tr className="bg-[#1E3A5F] text-white">
                <th className="p-2 text-left rounded-tl-lg">Mois</th>
                <th className="p-2 text-right" colSpan={3}>Nuitées</th>
                <th className="p-2 text-right" colSpan={3}>TO Lit %</th>
                <th className="p-2 text-right" colSpan={3}>ADR</th>
                <th className="p-2 text-right rounded-tr-lg" colSpan={2}>Arrivées</th>
              </tr>
              <tr className="bg-[#2E4F7A] text-white/70 text-xs">
                <th className="p-2 text-left">Mois</th>
                <th className="p-2 text-right">{annee}</th><th className="p-2 text-right">{annee-1}</th><th className="p-2 text-right">Δ%</th>
                <th className="p-2 text-right">{annee}</th><th className="p-2 text-right">{annee-1}</th><th className="p-2 text-right">Δ%</th>
                <th className="p-2 text-right">{annee}</th><th className="p-2 text-right">{annee-1}</th><th className="p-2 text-right">Δ%</th>
                <th className="p-2 text-right">{annee}</th><th className="p-2 text-right">{annee-1}</th>
              </tr>
            </thead>
            <tbody>
              {compar.map((r, i) => (
                <tr key={i} className={i % 2 === 0 ? "bg-white" : "bg-gray-50"}>
                  <td className="p-2 font-semibold text-gray-700">{r.mois_nom}</td>
                  <td className="p-2 text-right font-mono">{fmt(r.nuitees_n)}</td>
                  <td className="p-2 text-right font-mono text-gray-400">{fmt(r.nuitees_n1)}</td>
                  <td className="p-2 text-right"><Badge value={r.nuitees_growth_pct} /></td>
                  <td className="p-2 text-right font-mono">{fmt(r.to_lit_n, 1)}%</td>
                  <td className="p-2 text-right font-mono text-gray-400">{fmt(r.to_lit_n1, 1)}%</td>
                  <td className="p-2 text-right"><Badge value={r.to_lit_growth_pct} /></td>
                  <td className="p-2 text-right font-mono">{fmt(r.adr_n, 2)}</td>
                  <td className="p-2 text-right font-mono text-gray-400">{fmt(r.adr_n1, 2)}</td>
                  <td className="p-2 text-right"><Badge value={r.adr_growth_pct} /></td>
                  <td className="p-2 text-right font-mono">{fmt(r.arr_total_n)}</td>
                  <td className="p-2 text-right font-mono text-gray-400">{fmt(r.arr_total_n1)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </ChartCard>

      <Section
        title="Analyse détaillée des arrivées"
        subtitle="Répartition des arrivées par catégorie de clientèle et cumul annuel."
      />

      {/* 4. ARRIVÉES DÉTAILLÉES */}
      <div className="grid grid-cols-2 gap-4 mb-4">
        <ChartCard title="Arrivées par catégorie (mensuel)">
          <ResponsiveContainer width="100%" height={250}>
            <BarChart data={arrivees} barSize={12}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
              <XAxis dataKey="mois_nom" tick={{ fontSize: 10 }} />
              <YAxis tick={{ fontSize: 10 }} />
              <Tooltip />
              <Legend wrapperStyle={{ fontSize: 11 }} />
              <Bar dataKey="arr_adulte" name="Adultes" fill="#1E3A5F" radius={[3,3,0,0]} stackId="a" />
              <Bar dataKey="arr_enfant" name="Enfants" fill="#2E86AB" radius={[0,0,0,0]} stackId="a" />
              <Bar dataKey="arr_bebe"   name="Bébés"   fill="#A8DADC" radius={[3,3,0,0]} stackId="a" />
            </BarChart>
          </ResponsiveContainer>
        </ChartCard>

        <ChartCard title="Cumul arrivées annuel">
          <ResponsiveContainer width="100%" height={250}>
            <AreaChart data={arrivees}>
              <defs>
                <linearGradient id="gradArr" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%"  stopColor="#1E3A5F" stopOpacity={0.25} />
                  <stop offset="95%" stopColor="#1E3A5F" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
              <XAxis dataKey="mois_nom" tick={{ fontSize: 10 }} />
              <YAxis tick={{ fontSize: 10 }} />
              <Tooltip />
              <Area type="monotone" dataKey="arr_cumul" stroke="#1E3A5F" strokeWidth={2.5} fill="url(#gradArr)" name="Cumul arrivées" />
            </AreaChart>
          </ResponsiveContainer>
        </ChartCard>
      </div>

      <Section
        title="Segmentation par nationalité et par agence"
        subtitle="Identification des marchés sources et des partenaires clés en termes d’arrivées et de CA."
      />

      {/* 5. NATIONALITÉS & AGENCES */}
      <div className="grid grid-cols-2 gap-4 mb-4">
        <ChartCard title="Top 10 nationalités — arrivées">
          <ResponsiveContainer width="100%" height={280}>
            <BarChart data={nationalites.map(r => ({...r, nom_nat: r.nom_nat.replace(/^\d+\s+/, '')}))} layout="vertical" barSize={14}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
              <XAxis type="number" tick={{ fontSize: 10 }} />
              <YAxis dataKey="nom_nat" type="category" tick={{ fontSize: 10 }} width={85} />
              <Tooltip formatter={(v, n, p) => [
                `${fmt(v)} arrivées (${p.payload.part_pct}%)`
              ]} />
              <Bar dataKey="total_arrivees" fill="#457B9D" radius={[0,4,4,0]} name="Arrivées" />
            </BarChart>
          </ResponsiveContainer>
        </ChartCard>

        <ChartCard title="Top Agences — CA & Part %">
          <ResponsiveContainer width="100%" height={280}>
            <BarChart data={agences.filter(r => r.nom_agence && r.nom_agence !== 'nan').map(r => ({...r, nom_agence: r.nom_agence.length > 18 ? r.nom_agence.substring(0,18)+'…' : r.nom_agence}))} layout="vertical" barSize={14}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
              <XAxis type="number" tickFormatter={v => `${(v/1000000).toFixed(1)}M`} tick={{ fontSize: 10 }} />
              <YAxis dataKey="nom_agence" type="category" tick={{ fontSize: 9 }} width={110} />
              <Tooltip formatter={(v, n, p) => [
                `${fmtK(v)} TND (${p.payload.part_pct}%)`
              ]} />
              <Bar dataKey="ca_total" fill="#1A6B3A" radius={[0,4,4,0]} name="CA TND" />
            </BarChart>
          </ResponsiveContainer>
        </ChartCard>
      </div>

      {/* Tableau nationalités */}
      <div className="grid grid-cols-2 gap-4">
        <ChartCard
          title="Détail par nationalité"
          subtitle="Répartition des arrivées et part de marché par nationalité."
        >
          <table className="w-full text-xs">
            <thead>
              <tr className="bg-[#1E3A5F] text-white">
                <th className="p-2 text-left rounded-tl-lg">Nationalité</th>
                <th className="p-2 text-left">Continent</th>
                <th className="p-2 text-right">Arrivées</th>
                <th className="p-2 text-right rounded-tr-lg">Part %</th>
              </tr>
            </thead>
            <tbody>
              {nationalites.map((r, i) => (
                <tr key={i} className={i % 2 === 0 ? "bg-white" : "bg-gray-50"}>
                  <td className="p-2 font-medium text-gray-700">{r.nom_nat.replace(/^\d+\s+/, '')}</td>
                  <td className="p-2 text-gray-400">{r.continent}</td>
                  <td className="p-2 text-right font-mono">{fmt(r.total_arrivees)}</td>
                  <td className="p-2 text-right font-semibold text-[#457B9D]">{r.part_pct}%</td>
                </tr>
              ))}
            </tbody>
          </table>
        </ChartCard>

        <ChartCard
          title="Détail par agence"
          subtitle="Contribution des agences et canaux de distribution au chiffre d’affaires."
        >
          <table className="w-full text-xs">
            <thead>
              <tr className="bg-[#1E3A5F] text-white">
                <th className="p-2 text-left rounded-tl-lg">Agence</th>
                <th className="p-2 text-left">Canal</th>
                <th className="p-2 text-right">CA (TND)</th>
                <th className="p-2 text-right rounded-tr-lg">Part %</th>
              </tr>
            </thead>
            <tbody>
              {agences.filter(r => r.nom_agence && r.nom_agence !== 'nan').map((r, i) => (
                <tr key={i} className={i % 2 === 0 ? "bg-white" : "bg-gray-50"}>
                  <td className="p-2 font-medium text-gray-700">{r.nom_agence}</td>
                  <td className="p-2 text-gray-400">{r.type_canal}</td>
                  <td className="p-2 text-right font-mono">{fmtK(r.ca_total)} K</td>
                  <td className="p-2 text-right font-semibold text-[#1A6B3A]">{r.part_pct}%</td>
                </tr>
              ))}
            </tbody>
          </table>
        </ChartCard>
      </div>

    </div>
  );
}
