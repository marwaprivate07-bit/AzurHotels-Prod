export default function ChartCard({ title, subtitle, children, className = "", action, accent = "#1a8fd1", badge, badgeType = "pos" }) {
  return (
    <div className={className} style={{ display: "flex", flexDirection: "column", gap: "8px" }}>

      {/* Floating label above card */}
      <div style={{
        display: "flex", alignItems: "center", gap: "7px",
        fontSize: "12px", fontWeight: "700", color: "#1a2b4a",
        letterSpacing: "-0.01em", paddingLeft: "2px",
        flexWrap: "wrap",
      }}>
        <span style={{
          width: "8px", height: "8px", borderRadius: "50%",
          background: accent, flexShrink: 0,
          display: "inline-block",
        }} />
        {title}
        {subtitle && (
          <span style={{ fontSize: "10px", fontWeight: "500", color: "#7a95b0", marginLeft: "2px" }}>
            · {subtitle}
          </span>
        )}
      </div>

      {/* Card */}
      <div style={{
        background: "rgba(255,255,255,0.88)",
        borderRadius: "16px",
        border: "1px solid rgba(180,210,235,0.8)",
        borderLeft: `4px solid ${accent}`,
        overflow: "hidden",
        boxShadow: "0 2px 12px rgba(26,103,180,0.07), 0 1px 2px rgba(26,103,180,0.04)",
        transition: "box-shadow 0.2s ease, transform 0.2s ease",
        padding: "16px 20px 20px",
        backdropFilter: "blur(8px)",
      }}
        onMouseEnter={e => {
          e.currentTarget.style.boxShadow = "0 8px 28px rgba(26,103,180,0.14), 0 4px 10px rgba(26,103,180,0.07)";
          e.currentTarget.style.transform = "translateY(-2px)";
          e.currentTarget.style.borderColor = "rgba(26,143,209,0.4)";
        }}
        onMouseLeave={e => {
          e.currentTarget.style.boxShadow = "0 2px 12px rgba(26,103,180,0.07), 0 1px 2px rgba(26,103,180,0.04)";
          e.currentTarget.style.transform = "translateY(0)";
          e.currentTarget.style.borderColor = "rgba(180,210,235,0.8)";
        }}
      >
        {/* Badge row */}
        {(badge || action) && (
          <div style={{ display: "flex", justifyContent: "flex-end", marginBottom: "10px", gap: "8px", alignItems: "center" }}>
            {action && <div>{action}</div>}
            {badge && (
              <span style={{
                fontSize: "10px", fontWeight: "700", padding: "2px 9px", borderRadius: "999px",
                ...(badgeType === "pos"
                  ? { background: "rgba(0,168,107,0.1)", color: "#00a86b", border: "1px solid rgba(0,168,107,0.25)" }
                  : badgeType === "neg"
                  ? { background: "#fee2e2", color: "#dc2626", border: "1px solid #fca5a5" }
                  : { background: "rgba(26,143,209,0.08)", color: "#1a8fd1", border: "1px solid rgba(26,143,209,0.2)" }),
              }}>
                {badge}
              </span>
            )}
          </div>
        )}
        {children}
      </div>
    </div>
  );
}
