// Global context — hotel selector + year shared across all pages
import { createContext, useContext, useState, useEffect, useRef } from "react";
import { getHotels } from "../services/api";

const Ctx = createContext({ hotels:[], hotelId:1, setHotelId:()=>{}, annee:2024, setAnnee:()=>{}, hotel:null, printRef:{ current:null } });
export const useDashboard = () => useContext(Ctx);

export default function DashboardProvider({ children }) {
  const [hotels,   setHotels]   = useState([]);
  const [hotelId,  setHotelId]  = useState(1);
  const [annee,    setAnnee]    = useState(2024);
  const printRef = useRef(null);

  useEffect(() => {
    getHotels()
      .then(r => setHotels(r.data.data || []))
      .catch(() => setHotels([
        { hotel_id: 1, nom_hotel: "Royal Azur Thalassa", categorie: "5*" },
        { hotel_id: 2, nom_hotel: "Bel Azur",            categorie: "4*" },
      ]));
  }, []);

  const hotel = hotels.find(h => h.hotel_id === hotelId) || null;

  return (
    <Ctx.Provider value={{ hotels, hotelId, setHotelId, annee, setAnnee, hotel, printRef }}>
      {children}
    </Ctx.Provider>
  );
}
