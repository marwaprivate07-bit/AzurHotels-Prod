import { NavLink } from "react-router-dom";
import { useDashboard } from "./DashboardContext";
import royalAzurLogo from "../assets/royal_azur_logo.png";
import belAzurLogo from "../assets/bel_azur_logo.png";

const HOTEL_LOGOS = {
  1: royalAzurLogo,
  2: belAzurLogo,
};

const FALLBACK_NAME = {
  1: "Royal Azur Thalassa",
  2: "Bel Azur",
};

const IconCA = () => (
  <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
    <line x1="12" y1="1" x2="12" y2="23"/>
    <path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/>
  </svg>
);
const IconStats = () => (
  <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
    <line x1="18" y1="20" x2="18" y2="10"/>
    <line x1="12" y1="20" x2="12" y2="4"/>
    <line x1="6" y1="20" x2="6" y2="14"/>
  </svg>
);
const IconCharges = () => (
  <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
    <rect x="2" y="7" width="20" height="14" rx="2"/>
    <path d="M16 7V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v2"/>
    <line x1="12" y1="12" x2="12" y2="16"/>
    <line x1="10" y1="14" x2="14" y2="14"/>
  </svg>
);
const IconResultat = () => (
  <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
    <polyline points="22 7 13.5 15.5 8.5 10.5 2 17"/>
    <polyline points="16 7 22 7 22 13"/>
  </svg>
);
const IconLogout = () => (
  <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/>
    <polyline points="16 17 21 12 16 7"/>
    <line x1="21" y1="12" x2="9" y2="12"/>
  </svg>
);

const links = [
  { to: "/ca",       icon: <IconCA />,       label: "Chiffre d'Affaires" },
  { to: "/stats",    icon: <IconStats />,    label: "Statistiques"       },
  { to: "/charges",  icon: <IconCharges />,  label: "Charges"            },
  { to: "/resultat", icon: <IconResultat />, label: "Résultat"           },
];

export default function Sidebar({ user, onLogout }) {
  const { hotelId } = useDashboard();
  const logo = HOTEL_LOGOS[hotelId];

  return (
    <aside style={{
      width: "240px",
      minHeight: "100vh",
      flexShrink: 0,
      background: "linear-gradient(180deg, #050816 0%, #0f1f38 45%, #111827 100%)",
      display: "flex",
      flexDirection: "column",
      boxShadow: "6px 0 24px rgba(15,31,56,0.32)",
    }}>

      {/* ── Brand / Logo ── */}
      <div style={{
        padding: "12px 0",
        borderBottom: "1px solid rgba(255,255,255,0.07)",
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
      }}>
        {logo ? (
          <img
            src={logo}
            alt={FALLBACK_NAME[hotelId] || "Hotel Logo"}
            style={{
              width: "100%",
              maxHeight: "90px",
              objectFit: "contain",
              padding: "0 20px",
            }}
          />
        ) : (
          /* Fallback text logo if no image mapped */
          <div style={{ display: "flex", alignItems: "center", gap: "11px", padding: "0 20px" }}>
            <div style={{
              width: "38px", height: "38px", borderRadius: "10px", flexShrink: 0,
              background: "linear-gradient(135deg, #c9a84c 0%, #a07828 100%)",
              display: "flex", alignItems: "center", justifyContent: "center",
              boxShadow: "0 6px 20px rgba(201,168,76,0.45)",
            }}>
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
                <path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z" fill="white" opacity="0.95"/>
                <polyline points="9 22 9 12 15 12 15 22" fill="white" opacity="0.7"/>
              </svg>
            </div>
            <div>
              <div style={{ fontSize: "13px", fontWeight: "800", color: "#f9fafb", letterSpacing: "-0.02em", lineHeight: 1.2 }}>
                {FALLBACK_NAME[hotelId] || "Azur Hotels"}
              </div>
              <div style={{ fontSize: "9px", fontWeight: "600", color: "#c9a84c", letterSpacing: "0.16em", textTransform: "uppercase" }}>
                BI Dashboard
              </div>
            </div>
          </div>
        )}
        <div style={{ fontSize: "8px", fontWeight: "600", color: "#c9a84c", letterSpacing: "0.18em", textTransform: "uppercase", marginTop: "6px" }}>
          BI Dashboard
        </div>
      </div>

      {/* ── Nav ── */}
      <nav style={{ flex: 1, padding: "14px 10px 10px" }}>
        <div style={{
          fontSize: "9px",
          fontWeight: "700",
          color: "rgba(148,163,184,0.9)",
          letterSpacing: "0.16em",
          textTransform: "uppercase",
          padding: "4px 12px 10px",
        }}>
          Navigation
        </div>

        {links.map(l => (
          <NavLink key={l.to} to={l.to} style={{ textDecoration: "none" }}>
            {({ isActive }) => (
              <div
                style={{
                  display: "flex",
                  alignItems: "center",
                  gap: "10px",
                  padding: "9px 13px",
                  borderRadius: "10px",
                  marginBottom: "4px",
                  background: isActive ? "linear-gradient(90deg, rgba(240,165,0,0.15), rgba(240,165,0,0.06))" : "transparent",
                  color: isActive ? "#fff8e8" : "rgba(148,163,184,0.9)",
                  fontWeight: isActive ? "600" : "400",
                  fontSize: "12px",
                  borderLeft: isActive ? "3px solid #c9a84c" : "3px solid transparent",
                  transition: "all 0.15s",
                  cursor: "pointer",
                }}
                onMouseEnter={e => {
                  if (!isActive) {
                    e.currentTarget.style.background = "rgba(15,23,42,0.9)";
                    e.currentTarget.style.color = "#e5f2ff";
                  }
                }}
                onMouseLeave={e => {
                  if (!isActive) {
                    e.currentTarget.style.background = "transparent";
                    e.currentTarget.style.color = "rgba(148,163,184,0.9)";
                  }
                }}
              >
                <span
                  style={{
                    flexShrink: 0,
                    opacity: isActive ? 1 : 0.75,
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                  }}
                >
                  {l.icon}
                </span>
                <span style={{ whiteSpace: "nowrap" }}>{l.label}</span>
              </div>
            )}
          </NavLink>
        ))}
      </nav>

      {/* ── User footer ── */}
      <div style={{ padding: "14px 14px 18px", borderTop: "1px solid rgba(255,255,255,0.07)" }}>
        <div style={{ display: "flex", alignItems: "center", gap: "10px", marginBottom: "12px" }}>
          <div style={{
            width: "32px", height: "32px", borderRadius: "50%", flexShrink: 0,
            background: "linear-gradient(135deg, #c9a84c, #a07828)",
            display: "flex", alignItems: "center", justifyContent: "center",
          }}>
            <span style={{ color: "#7a3f00", fontSize: "12px", fontWeight: "800" }}>
              {(user?.name || "A")[0].toUpperCase()}
            </span>
          </div>
          <div style={{ overflow: "hidden" }}>
            <div style={{ fontSize: "12px", fontWeight: "700", color: "#fff", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>
              {user?.name || "Administrateur"}
            </div>
            <div style={{ fontSize: "10px", color: "rgba(255,255,255,0.32)", letterSpacing: "0.04em" }}>
              Admin
            </div>
          </div>
        </div>

        <button onClick={onLogout} style={{
          width: "100%", display: "flex", alignItems: "center", justifyContent: "center", gap: "6px",
          padding: "8px", borderRadius: "8px",
          background: "rgba(255,255,255,0.05)",
          border: "1px solid rgba(255,255,255,0.08)",
          color: "rgba(255,255,255,0.38)",
          fontSize: "11px", fontWeight: "600",
          cursor: "pointer", letterSpacing: "0.04em",
          transition: "all 0.15s",
        }}
          onMouseEnter={e => { e.currentTarget.style.background = "rgba(255,80,80,0.12)"; e.currentTarget.style.color = "#ff6b6b"; e.currentTarget.style.borderColor = "rgba(255,80,80,0.25)"; }}
          onMouseLeave={e => { e.currentTarget.style.background = "rgba(255,255,255,0.05)"; e.currentTarget.style.color = "rgba(255,255,255,0.38)"; e.currentTarget.style.borderColor = "rgba(255,255,255,0.08)"; }}
        >
          <IconLogout /> Déconnexion
        </button>
      </div>
    </aside>
  );
}