export default function KpiCard({ title, value, subtitle, delta, color = "#1a8fd1", icon, gauge }) {
  const isPos = delta ? !delta.startsWith("-") : null;

  return (
    <div
      style={{
        background: "rgba(255,255,255,0.88)",
        borderRadius: "16px",
        padding: "18px 18px 16px",
        border: "1px solid rgba(180,210,235,0.8)",
        display: "flex",
        flexDirection: "column",
        position: "relative",
        overflow: "hidden",
        boxShadow: "0 2px 12px rgba(26,103,180,0.07), 0 1px 2px rgba(26,103,180,0.04)",
        transition: "box-shadow 0.2s cubic-bezier(0.4,0,0.2,1), transform 0.2s cubic-bezier(0.4,0,0.2,1)",
        cursor: "default",
        backdropFilter: "blur(8px)",
      }}
      onMouseEnter={e => {
        e.currentTarget.style.boxShadow = "0 8px 28px rgba(26,103,180,0.16), 0 4px 10px rgba(26,103,180,0.08)";
        e.currentTarget.style.transform = "translateY(-3px)";
        e.currentTarget.style.borderColor = "rgba(26,143,209,0.45)";
      }}
      onMouseLeave={e => {
        e.currentTarget.style.boxShadow = "0 2px 12px rgba(26,103,180,0.07), 0 1px 2px rgba(26,103,180,0.04)";
        e.currentTarget.style.transform = "translateY(0)";
        e.currentTarget.style.borderColor = "rgba(180,210,235,0.8)";
      }}
    >
      {/* Top gradient line */}
      <div style={{
        position: "absolute",
        top: 0, left: 0, right: 0,
        height: "2px",
        background: color === "#c9a84c" || color === "#00a86b"
          ? `linear-gradient(90deg, #c9a84c, ${color}88)`
          : `linear-gradient(90deg, ${color}, ${color}88)`,
        borderRadius: "16px 16px 0 0",
      }} />

      {/* Decorative blob top-right */}
      <div style={{
        position: "absolute",
        top: "-28px",
        right: "-28px",
        width: "110px",
        height: "110px",
        borderRadius: "50%",
        background: `radial-gradient(circle at 30% 0%, ${color}22 0, ${color}00 60%)`,
        pointerEvents: "none",
      }} />

      {/* Row 1: icon + delta */}
      <div style={{
        display: "flex",
        alignItems: "flex-start",
        justifyContent: "space-between",
        marginBottom: "14px",
        marginTop: "4px",
      }}>
        {icon && (
          <div style={{
            width: "38px",
            height: "38px",
            borderRadius: "10px",
            background: `${color}18`,
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            color: color,
            flexShrink: 0,
          }}>
            {icon}
          </div>
        )}
        {delta ? (
          <span style={{
            fontSize: "11px", fontWeight: "700",
            color: isPos ? "#00a86b" : "#dc2626",
            background: isPos ? "rgba(0,168,107,0.1)" : "#fee2e2",
            border: `1px solid ${isPos ? "rgba(0,168,107,0.25)" : "#fca5a5"}`,
            borderRadius: "999px", padding: "3px 10px",
          }}>
            {isPos ? "+" : ""}{delta}
          </span>
        ) : <div />}
      </div>

      {/* Title */}
      <span style={{
        fontSize: "10px",
        fontWeight: "600",
        color: "#7a95b0",
        lineHeight: 1.4,
        marginBottom: "6px",
        textTransform: "uppercase",
        letterSpacing: "0.1em",
      }}>
        {title}
      </span>

      {/* Value */}
      <span style={{
        fontSize: "24px",
        fontWeight: "800",
        color: "#1a2b4a",
        letterSpacing: "-0.04em",
        lineHeight: 1,
      }}>
        {value}
      </span>

      {/* Subtitle */}
      {subtitle && (
        <span style={{
          fontSize: "10px",
          color: "#7a95b0",
          marginTop: "6px",
          display: "flex",
          alignItems: "center",
          gap: "4px",
        }}>
          {subtitle}
        </span>
      )}

      {/* Optional gauge bar */}
      {gauge != null && (
        <div style={{ marginTop: "10px" }}>
          <div style={{ height: 5, borderRadius: 99, background: "rgba(180,210,235,0.35)" }}>
            <div style={{ height: "100%", width: `${Math.min(Math.max(gauge, 0), 100)}%`, background: color, borderRadius: 99 }} />
          </div>
          <div style={{ display: "flex", justifyContent: "space-between", fontSize: 8, color: "#b0c4d8", marginTop: 2 }}>
            <span>0%</span><span>50%</span><span>100%</span>
          </div>
        </div>
      )}
    </div>
  );
}
