import { useLocation } from "react-router-dom";
import { useDashboard } from "./DashboardContext";


const titles = {
  "/ca":       { label: "Chiffre d'Affaires", sub: "Revenus & performance"  },
  "/stats":    { label: "Statistiques",        sub: "Indicateurs hôteliers" },
  "/charges":  { label: "Charges",             sub: "Analyse des coûts"     },
  "/resultat": { label: "Résultat Net",         sub: "CA vs charges"         },
};

// ── SVG icons ────────────────────────────────────────────────────────────────
const ChevronDown = () => (
  <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
    <polyline points="6 9 12 15 18 9"/>
  </svg>
);
const HotelIcon = () => (
  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <rect x="4" y="2" width="16" height="20" rx="1"/>
    <path d="M9 22V12h6v10"/><line x1="9" y1="7" x2="9.01" y2="7" strokeWidth="3"/>
    <line x1="15" y1="7" x2="15.01" y2="7" strokeWidth="3"/>
  </svg>
);
const DownloadIcon = () => (
  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/>
    <polyline points="7 10 12 15 17 10"/>
    <line x1="12" y1="15" x2="12" y2="3"/>
  </svg>
);
const CalIcon = () => (
  <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <rect x="3" y="4" width="18" height="18" rx="2"/>
    <line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/>
    <line x1="3" y1="10" x2="21" y2="10"/>
  </svg>
);

export default function Topbar({ user: userProp }) {
  const loc  = useLocation();
  const page = titles[loc.pathname] || { label: "Dashboard", sub: "" };
  const ctx        = useDashboard() || {};
  const hotels     = ctx.hotels     ?? [];
  const hotelId    = ctx.hotelId    ?? 1;
  const setHotelId = ctx.setHotelId ?? (() => {});
  const annee      = ctx.annee      ?? 2024;
  const setAnnee   = ctx.setAnnee   ?? (() => {});

  // Read user from prop or fallback to localStorage
  const user = userProp || (() => {
    try { return JSON.parse(localStorage.getItem("bi_user")); } catch { return null; }
  })();

  const now  = new Date();
  const time = now.toLocaleTimeString("fr-TN", { hour: "2-digit", minute: "2-digit" });
  const date = now.toLocaleDateString("fr-TN", { weekday: "short", day: "numeric", month: "short" });

  const pageKey = loc.pathname.replace("/", "") || "ca";

  const handleExport = () => {
    // Force all ResponsiveContainers to a fixed size so Recharts re-renders SVGs properly
    const containers = document.querySelectorAll(".recharts-responsive-container");
    const origStyles = [];

    containers.forEach((el, i) => {
      origStyles[i] = { width: el.style.width, height: el.style.height };
      const h = el.offsetHeight || 230;
      el.style.width = "100%";
      el.style.height = h + "px";
    });

    // Give Recharts a tick to re-render, then print
    setTimeout(() => {
      window.print();
      // Restore after print dialog closes
      setTimeout(() => {
        containers.forEach((el, i) => {
          el.style.width = origStyles[i].width;
          el.style.height = origStyles[i].height;
        });
      }, 1000);
    }, 300);
  };

  return (
    <div data-topbar="true" style={{
      height: "60px",
      background: "rgba(255,255,255,0.82)",
      borderBottom: "1px solid rgba(180,210,235,0.7)",
      backdropFilter: "blur(12px)",
      WebkitBackdropFilter: "blur(12px)",
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between",
      padding: "0 22px",
      flexShrink: 0,
      gap: "12px",
      boxShadow: "0 14px 40px rgba(15,23,42,0.08)",
    }}>

      {/* ── LEFT: page title ── */}
      <div style={{ display: "flex", alignItems: "center", gap: "10px", flexShrink: 0 }}>
        <div style={{ width: "7px", height: "7px", borderRadius: "50%", background: "#1a8fd1", boxShadow: "0 0 8px #1a8fd1" }} />
        <span style={{ fontSize: "14px", fontWeight: "700", color: "#0f172a", letterSpacing: "-0.02em" }}>
          {page.label}
        </span>
        {page.sub && (
          <span style={{ fontSize: "11px", color: "#9ca3af" }}>{page.sub}</span>
        )}
      </div>

      {/* ── CENTER: hotel selector + year selector ── */}
      <div style={{ display: "flex", alignItems: "center", gap: "10px" }}>

        {/* Hotel selector */}
        <div style={{ position: "relative" }}>
          <div style={{
            display: "flex",
            alignItems: "center",
            gap: "8px",
            background: "#f0f6fc",
            border: "1px solid rgba(180,210,235,0.8)",
          }}>
            <HotelIcon />
            <select
              value={hotelId}
              onChange={e => setHotelId(+e.target.value)}
              style={{
                background: "transparent", border: "none", outline: "none",
                fontSize: "12px",
                fontWeight: "600",
                color: "#111827",
                cursor: "pointer",
                flex: 1,
                appearance: "none",
              }}
            >
              {hotels.length === 0 && (
                <>
                  <option value={1}>Royal Azur Thalassa ★★★★★</option>
                  <option value={2}>Bel Azur ★★★★</option>
                </>
              )}
              {hotels.map(h => (
                <option key={h.hotel_id} value={h.hotel_id}>
                  {h.nom_hotel} {h.categorie === "5*" ? "★★★★★" : h.categorie === "4*" ? "★★★★" : h.categorie}
                </option>
              ))}
            </select>
            <ChevronDown />
          </div>
        </div>

        {/* Divider */}
        <div style={{ width: "1px", height: "20px", background: "#e8e3dc" }} />

        {/* Year selector */}
        <div style={{
          display: "flex",
          alignItems: "center",
          gap: "6px",
          background: "#f9fafb",
          border: "1px solid #e5e7eb",
          borderRadius: "999px",
          padding: "6px 12px",
        }}>
          <CalIcon />
          <select
            value={annee}
            onChange={e => setAnnee(+e.target.value)}
            style={{
              background: "transparent", border: "none", outline: "none",
              fontSize: "12px",
              fontWeight: "600",
              color: "#111827",
              cursor: "pointer",
              appearance: "none",
            }}
          >
            {[2023, 2024].map(y => (
              <option key={y} value={y}>{y}</option>
            ))}
          </select>
          <ChevronDown />
        </div>

        {/* Export button */}
        <button
          onClick={handleExport}
          style={{
            display: "flex",
            alignItems: "center",
            gap: "6px",
            background: "linear-gradient(135deg, #c9a84c, #a07828)",
            border: "none",
            borderRadius: "999px",
            padding: "7px 15px",
            color: "#fff",
            fontSize: "12px",
            fontWeight: "700",
            cursor: "pointer",
            transition: "background 0.15s, box-shadow 0.15s, transform 0.15s",
            letterSpacing: "0.02em",
            boxShadow: "0 4px 14px rgba(240,165,0,0.35)",
          }}
          onMouseEnter={e => {
            e.currentTarget.style.background = "linear-gradient(135deg, #e09400, #a86800)";
            e.currentTarget.style.boxShadow = "0 8px 24px rgba(240,165,0,0.5)";
            e.currentTarget.style.transform = "translateY(-1px)";
          }}
          onMouseLeave={e => {
            e.currentTarget.style.background = "linear-gradient(135deg, #c9a84c, #a07828)";
            e.currentTarget.style.boxShadow = "0 4px 14px rgba(240,165,0,0.35)";
            e.currentTarget.style.transform = "translateY(0)";
          }}
        >
          <DownloadIcon />
          Exporter
        </button>
      </div>

      {/* ── RIGHT: time + avatar ── */}
      <div style={{ display: "flex", alignItems: "center", gap: "12px", flexShrink: 0 }}>
        <div style={{ textAlign: "right" }}>
          <div style={{ fontSize: "11px", fontWeight: "600", color: "#4b5563" }}>{time}</div>
          <div style={{ fontSize: "10px", color: "#9ca3af", textTransform: "capitalize" }}>{date}</div>
        </div>
        <div style={{
          width: "32px", height: "32px", borderRadius: "50%",
          background: "linear-gradient(135deg, #c9a84c, #a07828)",
          display: "flex", alignItems: "center", justifyContent: "center",
          color: "#fff", fontSize: "12px", fontWeight: "700",
          flexShrink: 0,
        }}>
          {(user?.name || "Admin")?.[0]?.toUpperCase() ?? "A"}
        </div>
      </div>
    </div>
  );
}
