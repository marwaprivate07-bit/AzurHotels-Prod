export default function Section({ title, subtitle }) {
  return (
    <div className="flex items-start gap-3 mb-4 mt-8 first:mt-0">
      <div style={{
        width: "4px",
        height: "44px",
        borderRadius: "4px",
        background: "linear-gradient(180deg, #c9a84c, #1a8fd1)",
        flexShrink: 0,
        marginTop: "2px",
      }} />
      <div>
        <h2 style={{ fontSize: "18px", fontWeight: "700", color: "#1a2b4a", marginBottom: "3px", letterSpacing: "-0.02em" }}>
          {title}
        </h2>
        {subtitle && (
          <p style={{ fontSize: "12px", color: "#7a95b0" }}>{subtitle}</p>
        )}
      </div>
    </div>
  );
}
