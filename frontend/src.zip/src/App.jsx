import { useState } from "react";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import Login from "./pages/Login";
import CA from "./pages/CA";
import Stats from "./pages/Stats";
import Charges from "./pages/Charges";
import Resultat from "./pages/Resultat";
import Topbar from "./components/Topbar";
import Sidebar from "./components/Sidebar";
import DashboardProvider from "./components/DashboardContext";

export default function App() {
  const [user, setUser] = useState(() => {
    const u = localStorage.getItem("bi_user");
    return u ? JSON.parse(u) : null;
  });

  const handleLogin = (userData) => setUser(userData);

  const handleLogout = () => {
    localStorage.removeItem("bi_token");
    localStorage.removeItem("bi_user");
    setUser(null);
  };

  if (!user) return <Login onLogin={handleLogin} />;

  return (
    <BrowserRouter>
      <DashboardProvider>
        {/* Global background */}
        <div
          className="flex h-screen"
          style={{
            background:
              "radial-gradient(ellipse 80% 50% at 20% 10%, rgba(26,143,209,0.10) 0%, transparent 60%), radial-gradient(ellipse 60% 40% at 80% 80%, rgba(14,160,206,0.07) 0%, transparent 60%), linear-gradient(180deg, #e8f0f8 0%, #ddeaf5 100%)",
          }}
        >
          {/* Sidebar */}
          <Sidebar user={user} onLogout={handleLogout} />

          {/* Right side layout */}
          <div className="flex flex-col flex-1">
            {/* Topbar */}
            <Topbar user={user} />

            {/* Pages */}
            <main
              className="flex-1 overflow-auto"
              style={{
                padding: "18px 22px 22px",
              }}
            >
              <div
                className="mx-auto"
                style={{
                  maxWidth: "1240px",
                  minHeight: "100%",
                }}
              >
                <Routes>
                  <Route path="/" element={<Navigate to="/ca" />} />
                  <Route path="/ca" element={<CA />} />
                  <Route path="/stats" element={<Stats />} />
                  <Route path="/charges" element={<Charges />} />
                  <Route path="/resultat" element={<Resultat />} />
                  <Route path="*" element={<Navigate to="/ca" replace />} />
                </Routes>
              </div>
            </main>
          </div>
        </div>
      </DashboardProvider>
    </BrowserRouter>
  );
}